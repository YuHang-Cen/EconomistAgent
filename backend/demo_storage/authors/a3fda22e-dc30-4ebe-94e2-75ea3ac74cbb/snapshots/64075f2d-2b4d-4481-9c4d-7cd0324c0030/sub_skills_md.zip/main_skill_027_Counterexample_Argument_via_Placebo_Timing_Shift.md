---
name: "Counterexample Argument via Placebo Timing Shift"
type: "sub_skill"
description: "This method is applicable when a causal identification strategy relies on a specific time-based discontinuity (e.g., a policy implementation year) and requires validation that no other time point could plausibly produce the same effect. It is used to rule out alternative timing explanations and confirm the uniqueness of the designated cutoff."
section_id: "714b74e1-5437-4fe5-8d5e-77cd3d69fa85"
main_skill_id: "main_skill_027"
normalized_pattern: "Counterexample Argument"
source_chunk_ids: [4]
---

# Counterexample Argument via Placebo Timing Shift

## Description

This method is applicable when a causal identification strategy relies on a specific time-based discontinuity (e.g., a policy implementation year) and requires validation that no other time point could plausibly produce the same effect. It is used to rule out alternative timing explanations and confirm the uniqueness of the designated cutoff.

## Method Program Summary

For each candidate alternative time point (e.g., one year before or after the actual event), treat it as the hypothetical event time and re-estimate the same regression model with an interaction term for that shifted point. If the interaction term becomes insignificant when the shift is after the true event, or becomes significant when the shift is before the true event, the alternative timing is invalid. By systematically testing and rejecting all plausible alternative time points, the method isolates the original event time as the only valid causal discontinuity.

## Method Program Example

作者首先假设政策发生在除2003年外的其他年份（如2002年），然后通过回归检验交互项系数是否显著。若假设拐点后的交互项不显著，或假设拐点前的交互项显著，则说明该替代拐点不成立。通过逐一排除所有可能的替代年份，最终确认2003年是唯一真实的政策拐点。

## Abstract Action Chain

1. Construct counterfactual scenarios by shifting the assumed event time forward or backward
2. Test the significance of the interaction term under each shifted timing assumption
3. Evaluate whether the shifted timing produces spurious significant effects or fails to replicate the original pattern
4. Iteratively eliminate all plausible alternative time points
5. Conclude the uniqueness of the original event time as the sole valid discontinuity