---
name: "Evidence-Based Critique and Policy Recommendation"
type: "sub_skill"
description: "This method is applicable when a commonly held belief, popular opinion, or widely accepted claim needs to be critically examined and potentially revised. It is triggered by the presence of a dominant narrative that may be incomplete, misleading, or incorrect, and where a more rigorous, data-driven analysis is required to inform decision-making or policy."
section_id: "8efa11e9-7fc0-4114-8a71-d110733a31b2"
main_skill_id: "main_skill_032"
normalized_pattern: "Comparative Analysis"
source_chunk_ids: [6]
---

# Evidence-Based Critique and Policy Recommendation

## Description

This method is applicable when a commonly held belief, popular opinion, or widely accepted claim needs to be critically examined and potentially revised. It is triggered by the presence of a dominant narrative that may be incomplete, misleading, or incorrect, and where a more rigorous, data-driven analysis is required to inform decision-making or policy.

## Method Program Summary

Begin by explicitly stating the popular belief or common assumption that will be the subject of critique. Then, systematically introduce empirical data, including findings from original research or international comparisons, to demonstrate the limitations or inaccuracies of the initial claim. Next, employ logical reasoning and a cost-benefit framework to weigh the trade-offs and consequences associated with the claim or its alternatives. Based on this structured evaluation, formulate a corrected or nuanced understanding of the issue. Finally, translate this revised understanding into concrete, actionable policy recommendations or strategic conclusions.

## Method Program Example

作者首先提出一个关于城市发展、移民或人口规模的流行观点或问题，然后通过引用自己的实证研究、国际比较数据以及逻辑推理，分析该观点的局限性或错误之处。接着，作者运用成本收益分析框架，评估不同政策选择的利弊，最后基于分析提出具体的政策建议或结论。

## Abstract Action Chain

1. Identify and state the target claim or prevailing viewpoint.
2. Introduce empirical evidence and comparative data to challenge the claim.
3. Apply logical reasoning and cost-benefit analysis to evaluate the claim's validity.
4. Formulate a revised or alternative conclusion based on the analysis.
5. Derive actionable recommendations or policy implications from the revised conclusion.