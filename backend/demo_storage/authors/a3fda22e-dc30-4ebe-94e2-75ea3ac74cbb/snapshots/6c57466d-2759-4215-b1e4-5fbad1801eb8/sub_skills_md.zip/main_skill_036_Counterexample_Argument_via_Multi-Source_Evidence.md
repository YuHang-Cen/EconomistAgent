---
name: "Counterexample Argument via Multi-Source Evidence"
type: "sub_skill"
description: "This method is applicable when the goal is to refute a set of widely held misconceptions or opposing claims by systematically presenting counter-evidence from multiple independent sources (e.g., cross-national data, theoretical models, and empirical studies) to establish a new, alternative proposition."
section_id: "d62af320-aa94-432d-844a-3f22d3db8b41"
main_skill_id: "main_skill_036"
normalized_pattern: "Counterexample Argument"
source_chunk_ids: [10]
---

# Counterexample Argument via Multi-Source Evidence

## Description

This method is applicable when the goal is to refute a set of widely held misconceptions or opposing claims by systematically presenting counter-evidence from multiple independent sources (e.g., cross-national data, theoretical models, and empirical studies) to establish a new, alternative proposition.

## Method Program Summary

First, explicitly list the common misconceptions or opposing viewpoints that will be challenged. Then, deploy a series of comparative data visualizations (e.g., cross-national scatter plots or trend lines) to show that the target phenomenon does not conform to the misconceptions. Next, articulate a theoretical proposition that accounts for the observed data patterns, and support it with granular empirical findings (e.g., from sub-national or longitudinal studies). After that, perform a direct comparison between the target case and a well-understood benchmark case to isolate the specific anomaly or lag. Finally, synthesize all lines of evidence to assert the alternative proposition, thereby completing the refutation.

## Method Program Example

作者首先列出三个关于人口集聚的常见误解，然后依次使用三张跨国比较图表（集聚与人均GDP、集聚与阶段、地区差距与经济发展）进行数据反驳，指出中国集聚程度在国际上偏低。接着引入‘在集聚中走向平衡’的理论，并用中国县级数据研究加以验证。最后通过中美各省GDP与人口份额的对比，揭示中国真正的问题是人口集聚滞后于经济集聚，从而完成对误解的系统性反驳。

## Abstract Action Chain

1. Identify and enumerate the target misconceptions or opposing claims to be refuted.
2. Present cross-context comparative data (e.g., cross-national or cross-regional) to demonstrate the inadequacy of the misconceptions.
3. Introduce a theoretical mechanism or framework that explains the observed patterns and supports the alternative proposition.
4. Provide empirical evidence (e.g., sub-national or micro-level data) to validate the theoretical mechanism.
5. Synthesize the evidence by contrasting the target case with a benchmark case to highlight the core discrepancy.
6. Conclude by restating the alternative proposition as the correct interpretation, based on the cumulative evidence.