---
name: "Comparative Analysis with Theoretical Framework and Empirical Validation"
type: "sub_skill"
description: "This sub-skill is applicable when the goal is to analyze a complex socio-economic or policy issue by constructing a core metaphor or theoretical framework, comparing across historical periods or geographical contexts, introducing institutional or structural constraints, and validating the analysis with empirical data and case studies to derive policy implications."
section_id: "1b926607-4f91-4fbe-b1b5-982faa7ed9d3"
main_skill_id: "main_skill_029"
normalized_pattern: "Comparative Analysis"
source_chunk_ids: [3]
---

# Comparative Analysis with Theoretical Framework and Empirical Validation

## Description

This sub-skill is applicable when the goal is to analyze a complex socio-economic or policy issue by constructing a core metaphor or theoretical framework, comparing across historical periods or geographical contexts, introducing institutional or structural constraints, and validating the analysis with empirical data and case studies to derive policy implications.

## Method Program Summary

Begin by establishing a central metaphor or theoretical lens that encapsulates the core tension or dynamic of the issue. Then, systematically compare across different time periods (e.g., historical phases) to reveal causal patterns or shifts. Next, incorporate institutional or structural factors (e.g., labor policies, regulations) as additional explanatory layers. Extend the analysis by comparing across multiple countries or regions to identify how context shapes outcomes. Introduce a formal constraint or trade-off model (such as an impossible triangle) to articulate inherent conflicts or limits. Finally, use quantitative data (e.g., productivity metrics, supply indicators) and qualitative case studies to empirically test the framework, and conclude with policy implications that address the identified trade-offs.

## Method Program Example

首先，作者提出‘技术与教育的赛跑’这一核心隐喻作为分析主线，并以此对比美国20世纪前后两个四分之三时期的不同结果，揭示教育供给滞后导致收入分化的因果链条。接着，引入制度因素（工会弱化、最低工资变化）作为补充解释。然后，将分析扩展到中国，通过国际比较（美国、德国、日本等）和‘不可能三角’理论框架，论证在统一、效率与平衡之间存在内在冲突。最后，利用TFP增长率、土地供应数据、留守儿童案例等实证材料，检验行政干预资源配置的低效率，并推导出以人口自由流动和城市化实现‘人均平衡’的政策结论。

## Abstract Action Chain

1. Construct a core metaphor or analytical framework to define the central problem or dynamic.
2. Conduct historical or temporal comparisons to illustrate the evolution or divergence of the issue.
3. Introduce institutional, structural, or policy factors as mediating or explanatory variables.
4. Perform cross-national or cross-regional comparisons to highlight contextual differences.
5. Propose a theoretical constraint or trade-off model (e.g., impossible triangle) to bound the analysis.
6. Validate the framework with empirical data and case studies, then derive actionable policy recommendations.