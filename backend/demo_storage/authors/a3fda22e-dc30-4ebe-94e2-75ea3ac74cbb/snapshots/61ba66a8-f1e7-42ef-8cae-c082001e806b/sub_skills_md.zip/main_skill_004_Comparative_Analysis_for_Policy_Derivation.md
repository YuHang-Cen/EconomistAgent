---
name: "Comparative Analysis for Policy Derivation"
type: "sub_skill"
description: "This sub-skill is applicable when the goal is to explain a complex socio-economic phenomenon by comparing two or more entities (e.g., countries, regions, or cities) to identify structural mismatches or causal mechanisms, and to derive actionable policy implications or theoretical insights. It is particularly useful when the target audience holds a common misconception that can be refuted through cross-case evidence."
section_id: "ac93eda4-eec6-4053-8f32-63ae488b2e5e"
main_skill_id: "main_skill_004"
normalized_pattern: "Comparative Analysis"
source_chunk_ids: [2, 3]
---

# Comparative Analysis for Policy Derivation

## Description

This sub-skill is applicable when the goal is to explain a complex socio-economic phenomenon by comparing two or more entities (e.g., countries, regions, or cities) to identify structural mismatches or causal mechanisms, and to derive actionable policy implications or theoretical insights. It is particularly useful when the target audience holds a common misconception that can be refuted through cross-case evidence.

## Method Program Summary

Begin by posing a sharp comparative question that sets up a contrast between two or more cases, often to challenge a dominant narrative. Then, present empirical data (quantitative or qualitative) that visually or logically illustrates the disparity. Compute a derived metric (e.g., per capita values, ratios) to isolate the structural mismatch. Next, identify the key deviation or causal factor that explains why the cases differ, and explicitly refute the common misconception by showing it does not fit the evidence. Finally, synthesize the findings into a generalizable mechanism or set of policy principles, projecting how the observed dynamics will evolve or what actions should be taken in the target context.

## Method Program Example

作者首先通过一个假设性问题引出中美对比，然后展示两国GDP份额与人口份额的柱状图与曲线图，通过简单算术揭示美国人均GDP趋同而中国人均GDP差距大的事实。接着，作者否定中国流行的‘经济过度集聚导致不平衡’的观点，指出真正问题是人口集聚滞后于经济集聚。最后，作者基于规模经济与比较优势理论，预测中国未来将走向‘在集聚中走向平衡’的路径，并反复用‘柱子与曲线’的比喻强化这一机制。

## Abstract Action Chain

1. Frame a comparative question or hypothesis that challenges a prevailing assumption.
2. Present comparative data or case evidence (e.g., charts, metrics, or qualitative examples) to highlight key differences or patterns.
3. Compute or extract a derived indicator (e.g., per capita metrics, ratios) to reveal underlying structural mismatches.
4. Identify and articulate the core deviation or causal factor that explains the observed pattern.
5. Refute the common misconception by contrasting it with the evidence, and propose an alternative mechanism.
6. Generalize the findings into a predictive framework or policy recommendations applicable to the target context.