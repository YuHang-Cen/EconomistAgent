---
name: "Concept Decomposition for Policy Analysis"
type: "sub_skill"
description: "This sub-skill is applicable when the goal is to analyze a complex institutional or policy object (e.g., a land system, a regulation, or a social program) by breaking it down into its conceptual components, redefining its core terms, and then deriving differentiated recommendations based on contextual factors."
section_id: "6acf3a30-6488-482f-a641-8925aca709ee"
main_skill_id: "main_skill_011"
normalized_pattern: "Concept Decomposition"
source_chunk_ids: [3]
---

# Concept Decomposition for Policy Analysis

## Description

This sub-skill is applicable when the goal is to analyze a complex institutional or policy object (e.g., a land system, a regulation, or a social program) by breaking it down into its conceptual components, redefining its core terms, and then deriving differentiated recommendations based on contextual factors.

## Method Program Summary

Begin by applying a relevant theoretical lens to decompose the target concept into its essential attributes or rights, establishing a clear definition. Then, systematically identify and critique any common misunderstandings or false equivalencies that obscure the concept's true nature. Next, demonstrate how the concept's components can be logically separated or unbundled, which allows for more nuanced treatment. After establishing this conceptual clarity, introduce external comparative factors (such as geography or industry) that determine the concept's practical significance. Use these factors to classify the subject into a limited set of archetypes. Finally, for each archetype, derive and propose a tailored set of actions or policies that are logically consistent with the preceding analysis.

## Method Program Example

首先，从产权理论出发，明确宅基地的产权属性，指出其可交易性和可分割性是市场配置资源的前提。其次，批判性地辨析宅基地与社会保障的关系，论证宅基地不能替代社会保障，并指出限制流转的误区。然后，基于产权可分割性理论，论证宅基地权利可以分解，并强调明确权利界定的必要性。接着，引入地理与产业比较优势，说明宅基地价值取决于区位和产业条件。最后，以山西省吕梁市为例，将闲置宅基地分为四类（城市近郊、良好禀赋、偏远地区、易地搬迁），分别提出因地制宜的改革建议，并总结政策方向。

## Abstract Action Chain

1. Decompose the core concept into its fundamental attributes or rights using established theoretical frameworks.
2. Critically examine and refute common misconceptions or conflations associated with the concept.
3. Argue for the separability or divisibility of the concept's components to enable flexible application.
4. Identify key contextual or comparative factors (e.g., geographic, economic) that influence the concept's value or behavior.
5. Classify the object of analysis into distinct types based on the identified factors.
6. Formulate differentiated, context-specific recommendations or policy directions for each type.