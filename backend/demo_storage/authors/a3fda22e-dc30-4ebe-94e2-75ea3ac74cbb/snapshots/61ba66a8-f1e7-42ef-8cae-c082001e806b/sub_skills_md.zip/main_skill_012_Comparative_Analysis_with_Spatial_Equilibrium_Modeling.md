---
name: "Comparative Analysis with Spatial Equilibrium Modeling"
type: "sub_skill"
description: "This sub-skill is applicable when the goal is to evaluate a spatial or regional development pattern by comparing multiple geographic scales (international, national, sub-national) and using empirical data to challenge or refine existing policy assumptions. It is triggered when the analysis requires both cross-country benchmarking and within-country spatial decomposition to support a theoretical argument about agglomeration and balance."
section_id: "ab976eae-410a-403a-9024-cb947629c4e6"
main_skill_id: "main_skill_012"
normalized_pattern: "Comparative Analysis"
source_chunk_ids: [4]
---

# Comparative Analysis with Spatial Equilibrium Modeling

## Description

This sub-skill is applicable when the goal is to evaluate a spatial or regional development pattern by comparing multiple geographic scales (international, national, sub-national) and using empirical data to challenge or refine existing policy assumptions. It is triggered when the analysis requires both cross-country benchmarking and within-country spatial decomposition to support a theoretical argument about agglomeration and balance.

## Method Program Summary

Begin by conducting international and bilateral comparisons to establish a benchmark and identify a key spatial-economic discrepancy (e.g., population lagging behind economic agglomeration). Then, decompose data across multiple administrative or geographic levels (e.g., regional, city-level) to confirm the pattern and rule out aggregation bias. Next, build a theoretical model—such as a spatial equilibrium framework—to formalize the logic behind the observed pattern, often emphasizing comparative advantage and agglomeration effects. Subsequently, use econometric methods (e.g., OLS, IV) to test how geographic variables (e.g., distance to ports, distance to large cities) affect outcomes like GDP, population mobility, or investment elasticity. After establishing empirical evidence, compare the consequences of different policy interventions (e.g., promoting industries with vs. without comparative advantage) to diagnose spatial misallocation. Finally, derive policy recommendations that aim to balance efficiency and spatial equity, grounded in the model and empirical results.

## Method Program Example

首先，通过国际比较和中美比较，确立“人口集聚滞后于经济集聚”这一核心判断，并以此反驳“过度集聚”的流行看法。接着，从地区层面和地级市层面进行数据分解，进一步验证人口与经济集聚的不同步性。然后，构建一个基于比较优势的空间均衡理论模型，阐述“在集聚中走向平衡”的内在逻辑。在此基础上，运用计量回归方法，系统检验地理距离（到大港口、到大城市）对GDP、人口流动、投资弹性等关键经济指标的影响，揭示地理因素的决定性作用。最后，通过对比不同区域发展政策（如帮助发展有比较优势的产业 vs. 发展无比较优势的产业）的后果，批判性地分析现有政策导致的空间错配问题，并据此提出兼顾效率与平衡的政策建议。

## Abstract Action Chain

1. Establish a baseline through cross-country comparisons to identify a core discrepancy or pattern
2. Decompose data across multiple geographic scales (e.g., national, regional, local) to validate the observed discrepancy
3. Construct a theoretical model (e.g., spatial equilibrium) to explain the underlying mechanism
4. Apply econometric regression to test the relationship between geographic factors and key economic outcomes
5. Compare alternative policy scenarios to evaluate spatial misallocation or inefficiency
6. Synthesize findings into policy recommendations that reconcile efficiency and equity