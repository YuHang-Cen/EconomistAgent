---
name: "Causal Derivation via Rival Hypotheses and Exogenous Shocks"
type: "sub_skill"
description: "This sub-skill is applicable when the goal is to establish a causal relationship between a core explanatory variable and an outcome, particularly when facing potential omitted variable bias or alternative explanations. It is used to strengthen causal inference by systematically testing and ruling out rival hypotheses, controlling for confounders, and leveraging exogenous policy or environmental shocks for heterogeneity analysis."
section_id: "eef81f81-75fa-40ac-b7ea-2832ff0266bf"
main_skill_id: "main_skill_023"
normalized_pattern: "Causal Derivation"
source_chunk_ids: [9]
---

# Causal Derivation via Rival Hypotheses and Exogenous Shocks

## Description

This sub-skill is applicable when the goal is to establish a causal relationship between a core explanatory variable and an outcome, particularly when facing potential omitted variable bias or alternative explanations. It is used to strengthen causal inference by systematically testing and ruling out rival hypotheses, controlling for confounders, and leveraging exogenous policy or environmental shocks for heterogeneity analysis.

## Method Program Summary

Begin by explicitly stating a plausible rival hypothesis that could undermine the causal claim. Then, introduce a control variable that operationalizes this rival factor into the regression model, and observe whether the coefficient of the core explanatory variable remains statistically significant and stable in magnitude. Next, systematically add other potential confounders (e.g., economic or demographic variables) as controls to further test robustness. After establishing baseline robustness, identify an exogenous shock that creates a natural experiment. Split the sample into pre- and post-shock periods (or treatment/control groups based on exposure to the shock). Re-run the regression within each subsample, and compare the estimated coefficients. If the core effect is stronger or only present in the subsample affected by the shock, this provides evidence for a causal mechanism. Finally, integrate all findings—coefficient stability, exclusion of alternatives, and heterogeneous effects—to support the causal derivation.

## Method Program Example

首先，作者提出一个竞争性假设（地理因素可能影响新城建设），然后通过引入城市坡度变量作为控制变量进行回归，检验核心解释变量（土地产权保护传统）的系数是否稳健。接着，作者进一步排除房价作为替代解释，通过将房价加入控制变量进行回归。最后，利用2008年经济刺激政策作为外生冲击，将样本分为政策前后两个阶段进行异质性分析，通过比较回归系数的显著性和大小，论证土地产权保护传统在特定情境（经济刺激）下对新城规划效率的因果作用。

## Abstract Action Chain

1. Identify and formalize plausible rival hypotheses that could explain the observed relationship.
2. Introduce control variables representing the rival factors into the baseline regression to test the stability of the core coefficient.
3. Further exclude additional alternative explanations by sequentially adding relevant control variables.
4. Identify an exogenous shock (e.g., policy change, natural event) that partitions the sample into distinct contexts.
5. Conduct heterogeneity analysis by splitting the sample based on the exogenous shock and comparing regression coefficients across subsamples.
6. Synthesize the evidence from robustness checks and heterogeneity analysis to argue for the causal interpretation.