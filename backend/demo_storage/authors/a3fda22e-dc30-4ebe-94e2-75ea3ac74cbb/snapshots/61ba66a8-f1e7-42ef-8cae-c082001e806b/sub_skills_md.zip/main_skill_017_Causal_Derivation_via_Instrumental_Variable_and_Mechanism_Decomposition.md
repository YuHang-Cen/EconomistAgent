---
name: "Causal Derivation via Instrumental Variable and Mechanism Decomposition"
type: "sub_skill"
description: "This method is applicable when the goal is to establish a causal relationship from observational data, particularly when the core explanatory variable is potentially endogenous due to omitted variables or reverse causality. It is also used when the theoretical mechanism involves multiple channels (e.g., collective action vs. polarization) that need to be empirically distinguished."
section_id: "e4c9e1d5-340c-4ec2-9ec3-4780b19f81a7"
main_skill_id: "main_skill_017"
normalized_pattern: "Causal Derivation"
source_chunk_ids: [1, 2]
---

# Causal Derivation via Instrumental Variable and Mechanism Decomposition

## Description

This method is applicable when the goal is to establish a causal relationship from observational data, particularly when the core explanatory variable is potentially endogenous due to omitted variables or reverse causality. It is also used when the theoretical mechanism involves multiple channels (e.g., collective action vs. polarization) that need to be empirically distinguished.

## Method Program Summary

The method begins by deriving competing theoretical hypotheses from established theories, then specifies a linear regression model with a clearly defined core explanatory variable, outcome variable, and a set of control variables. Baseline OLS regression is run, progressively adding controls to check the stability of the coefficient. To mitigate endogeneity, an instrumental variable is constructed based on historical or exogenous shocks, and two-stage least squares (2SLS) is applied, with formal tests for instrument relevance and exogeneity. The mechanism is then decomposed by splitting the outcome into theoretically distinct sub-categories (e.g., collective vs. individual contributions) to isolate the causal channel. Interaction terms are introduced to test for moderation effects, such as complementarity or substitution between the core variable and a policy variable. Finally, the core explanatory variable is replaced with an alternative proxy to verify the robustness of the main findings.

## Method Program Example

作者首先基于集体行动理论和宗族极化理论提出宗族多样性影响农村公共品私人供给及政府支出效率的竞争性假说。然后构建截面线性回归模型，使用县级层面的历史数据，以姓氏数目和姓氏集中度衡量宗族多样性，以1949-1990年农村公共品私人供给金额、人均金额和虚拟变量为被解释变量。基准回归采用OLS，通过逐步加入经济发展、文化、地理等控制变量检验结果的稳健性。为缓解遗漏变量导致的内生性问题，作者先利用宗族多样性对城乡公共品供给影响的差异进行组间比较，再构造宋元之际战争次数作为工具变量进行2SLS估计，并详细论证工具变量的相关性和外生性。在机制分析中，作者将公共品私人供给区分为群众集资和个人捐赠，检验宗族多样性是否仅通过影响集体行动成本（集资）而非个人捐赠发挥作用。最后，通过引入宗族多样性与政府支出的交互项，检验宗族多样性对政府支出效率的调节效应，并控制宗族械斗变量排除极化理论的替代解释。

## Abstract Action Chain

1. Formulate competing theoretical hypotheses and specify the causal model with core variables and controls.
2. Conduct baseline regression (e.g., OLS) with progressive inclusion of control variables to assess robustness.
3. Address endogeneity by constructing a valid instrumental variable and performing 2SLS estimation, including validation of relevance and exogeneity.
4. Decompose the outcome variable into distinct sub-components to test specific theoretical mechanisms.
5. Test for interaction effects to examine moderating or complementary relationships between the core variable and other factors.
6. Perform robustness checks by substituting the core explanatory variable with alternative measures.