---
name: "Ideal-Reference Comparison"
type: "sub_skill"
description: "This method is applicable when the goal is to evaluate or analyze a real-world system, policy, or phenomenon by contrasting it with a normative or idealized framework. It is particularly useful for identifying gaps, deviations, or shortcomings in the current state relative to a desired or theoretical standard, and for generating reform directions or improvement strategies."
section_id: "195d2a2a-eda7-4167-8f23-093cca35d300"
main_skill_id: "main_skill_014"
normalized_pattern: "Concept Comparison"
source_chunk_ids: [7]
---

# Ideal-Reference Comparison

## Description

This method is applicable when the goal is to evaluate or analyze a real-world system, policy, or phenomenon by contrasting it with a normative or idealized framework. It is particularly useful for identifying gaps, deviations, or shortcomings in the current state relative to a desired or theoretical standard, and for generating reform directions or improvement strategies.

## Method Program Summary

First, define a normative or ideal reference framework that embodies the desired goals, values, or principles, and explicitly break it down into its core dimensions. Then, systematically compare the actual system or phenomenon against each dimension of this reference, noting where and how the reality diverges. Next, investigate the historical, institutional, or contextual factors that have caused these divergences. Finally, based on the identified gaps and their root causes, formulate concrete recommendations or reform pathways to move the real system closer to the ideal reference.

## Method Program Example

作者首先构建了一个‘长期、全局、多维的发展’作为理想参照系，并对其三个维度进行详细分解。随后，将中国特色社会主义市场经济体制（包括一般性、社会主义价值观、中国特色）与该参照系进行系统比较，识别出地方政府行为等现实因素与理想目标之间的偏差。最后，通过历史追溯（从计划经济到双轨制再到市场定价）解释这些偏差的体制根源，并据此提出完善市场经济体制的改革方向。

## Abstract Action Chain

1. Construct an ideal reference framework with clearly defined dimensions or criteria
2. Decompose the reference framework into its constituent dimensions or principles
3. Map the real-world system or phenomenon onto the same dimensions for systematic comparison
4. Identify specific deviations or gaps between the real system and the ideal reference
5. Trace the historical or structural origins of the identified deviations
6. Propose targeted adjustments or reforms to align the real system with the ideal reference