---
name: "Ideal Reference Comparison"
type: "sub_skill"
description: "This method is applicable when evaluating multiple competing theories or approaches against a normative standard. It is used to systematically identify the strengths and weaknesses of each alternative by measuring their deviation from an idealized reference point, thereby justifying the need for a more comprehensive or superior solution."
section_id: "dbb78f77-c718-431d-871c-6a3650b9bb09"
main_skill_id: "main_skill_020"
normalized_pattern: "Concept Comparison"
source_chunk_ids: [6]
---

# Ideal Reference Comparison

## Description

This method is applicable when evaluating multiple competing theories or approaches against a normative standard. It is used to systematically identify the strengths and weaknesses of each alternative by measuring their deviation from an idealized reference point, thereby justifying the need for a more comprehensive or superior solution.

## Method Program Summary

First, construct an idealized reference frame that represents the optimal or desired state across multiple relevant dimensions. This reference serves as the absolute standard for evaluation. Next, list all competing theories, models, or approaches that need to be compared. For each alternative, systematically map its characteristics onto the same dimensions defined by the reference frame, and measure the degree of deviation or alignment. Based on these comparisons, pinpoint the specific limitations or shortcomings of each alternative. Finally, integrate the insights from all comparisons to propose a new direction or solution that overcomes the collective limitations, moving closer to the ideal reference.

## Method Program Example

首先，作者设定了一个理想化的参照系，即“长期的全局的多目标最优”，作为评估标准。然后，作者依次引入周黎安、张五常、陈钊和徐彤、以及陆铭等人的理论。对于每个理论，作者都将其与参照系进行对比，明确指出其在“长期”、“全局”、“多目标”这三个维度上的偏离或不足。通过这种比较，作者揭示了现有理论的局限性，并最终论证了构建一个能够综合这三个维度的新理论的必要性。

## Abstract Action Chain

1. Define an idealized reference frame as the evaluation benchmark
2. Enumerate the set of competing alternatives to be assessed
3. For each alternative, compare its key dimensions against the reference frame
4. Identify specific limitations or gaps in each alternative based on deviations
5. Synthesize findings to argue for a direction that addresses the identified gaps