---
name: "Comparative System Analysis"
type: "sub_skill"
description: "Use this method when you need to understand a complex system, policy, or social coordination problem by comparing it to a simpler or contrasting system. It is appropriate when the target system's mechanisms are unclear, its problems are conflated, or when evaluating the applicability and consequences of different coordination principles."
section_id: "758d72bc-900e-4882-bb81-d8e07787d8a9"
main_skill_id: "main_skill_001"
normalized_pattern: "Comparative Analysis"
source_chunk_ids: [2, 7]
---

# Comparative System Analysis

## Description

Use this method when you need to understand a complex system, policy, or social coordination problem by comparing it to a simpler or contrasting system. It is appropriate when the target system's mechanisms are unclear, its problems are conflated, or when evaluating the applicability and consequences of different coordination principles.

## Method Program Summary

Begin by selecting or constructing a comparative framework—either a familiar analogous system or a model based on contrasting core principles (e.g., voluntary cooperation vs. coercion). Systematically decompose this framework to define its fundamental operational components, functional problems, or normative logics. Then, apply this decomposition to the target complex system by mapping each defined element onto corresponding aspects of the target, thereby disentangling conflated issues and revealing structural parallels. Using this clarified mapping, analyze the conditions—such as the nature of the goods involved (divisible/indivisible) or the type of problem—that determine the applicability or necessity of each mechanism or principle within the target context. Finally, assess the broader consequences, interdependencies, or policy effectiveness that emerge from this comparative analysis, evaluating how the system's design aligns with or diverges from the comparative model's logic.

## Method Program Example

The method begins by introducing a comparative framework through a bank analogy to disentangle two conflated issues: the balance of payments (income account) and the danger of a gold run (liquidity crisis). It systematically decomposes the bank's operations to define these problems clearly, then applies this decomposition to the U.S. international monetary position, showing the precise parallels. This analytical separation allows the author to then examine how the two problems are interrelated in the U.S. context and to use this clarified structure as a basis for subsequently evaluating the mechanisms (like the fixed gold price) adopted to address them.

## Abstract Action Chain

1. Establish a comparative framework using a simpler analogous system or a contrasting principle-based model.
2. Decompose the comparative model to isolate and define its core functional components, mechanisms, or normative principles.
3. Map the defined components or principles onto the target system to clarify its structure and identify parallel relationships.
4. Derive the conditions or domains where each identified mechanism or principle is necessary or applicable based on the problem's characteristics.
5. Evaluate the systemic consequences, interdependencies, or policy implications revealed by the clarified analytical structure.