---
name: "Deriving Causal Principles from Systematic Policy Failure"
type: "sub_skill"
description: "This method is used when analyzing multiple instances of a social, economic, or organizational intervention that have produced outcomes systematically opposite to their stated intentions, in order to uncover the underlying causal mechanism responsible for the pattern of failure."
section_id: "e98009a9-2e3f-4b8e-ab74-c15bed110753"
main_skill_id: "main_skill_004"
normalized_pattern: "Causal Derivation"
source_chunk_ids: [5]
---

# Deriving Causal Principles from Systematic Policy Failure

## Description

This method is used when analyzing multiple instances of a social, economic, or organizational intervention that have produced outcomes systematically opposite to their stated intentions, in order to uncover the underlying causal mechanism responsible for the pattern of failure.

## Method Program Summary

Begin by inductively surveying multiple cases of a similar type of intervention. For each case, clearly juxtapose its officially stated goals and intended functioning against its documented real-world effects, highlighting unintended consequences and negative outcomes. This comparison reveals a recurring empirical pattern where results contradict intentions. Next, analyze the common element present in all cases that failed—typically a fundamental conflict, such as forcing action against individual interest or violating a core systemic principle. From this common flaw, deduce a general causal mechanism that logically explains how the flaw generates the observed pattern of failure. Finally, demonstrate the explanatory power of this derived principle by showing how it accounts for the systematic divergence between intent and result in each surveyed case.

## Method Program Example

The method begins with an inductive survey of multiple historical cases of government intervention (monetary reform, agricultural programs, housing, labor law, social security). For each case, the author juxtaposes the program's intended goals with its actual, often opposite, effects. This establishes an empirical pattern of recurrent failure. From this pattern, the author moves to deduction, positing a single underlying causal mechanism: that programs which seek to force individuals to act against their own immediate interests are inherently counteracted by the creative force of individuals pursuing their own values. This derived principle is then presented as the general explanation for the observed failures across all cases.

## Abstract Action Chain

1. Catalog the stated objectives and intended mechanisms of multiple intervention cases.
2. Document the observed negative outcomes and unintended consequences for each case, establishing a pattern of systematic failure.
3. Analyze the common structural flaw or conflict present across all failing cases.
4. Formulate a general causal principle that explains why the structural flaw leads to the observed pattern of failure.
5. Apply the derived principle to explain the divergence between intent and result across the original cases.