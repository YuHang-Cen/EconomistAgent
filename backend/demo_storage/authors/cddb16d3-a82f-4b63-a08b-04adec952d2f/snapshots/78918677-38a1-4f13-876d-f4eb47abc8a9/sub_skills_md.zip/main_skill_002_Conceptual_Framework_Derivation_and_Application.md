---
name: "Conceptual Framework Derivation and Application"
type: "sub_skill"
description: "This method is used when analyzing a complex, abstract domain to determine the appropriate functions or rules for a governing system. It is triggered by the need to move from vague principles (like 'freedom') to specific, actionable guidelines for institutional design, particularly where conflicts inherent in the principles create ambiguity."
section_id: "f2fc4ba9-983c-41ef-8eab-c39743de0526"
main_skill_id: "main_skill_002"
normalized_pattern: "Concept Decomposition"
source_chunk_ids: [8]
---

# Conceptual Framework Derivation and Application

## Description

This method is used when analyzing a complex, abstract domain to determine the appropriate functions or rules for a governing system. It is triggered by the need to move from vague principles (like 'freedom') to specific, actionable guidelines for institutional design, particularly where conflicts inherent in the principles create ambiguity.

## Method Program Summary

Begin by distinguishing between the observable activities within a system and the institutional framework that structures them. To define this framework's role, employ a clarifying analogy (e.g., rules of a game) to extract its essential functions, such as rule-setting, arbitration, and enforcement. Ground the necessity of this framework in a logical analysis of a core, irreconcilable conflict (e.g., between competing freedoms) that makes an ungoverned system impossible. Finally, use this analytically derived framework as a tool to decompose a broad problem area. Systematically apply it to isolate and examine specific, contentious sub-problems where the foundational conflict manifests, thereby translating abstract principles into precise criteria for institutional action and rule definition.

## Method Program Example

The method begins by establishing a fundamental conceptual distinction between the surface level of day-to-day activities and the underlying institutional framework that governs them. This framework is then clarified through an extended analogy to the rules of a game, which yields three core governmental functions: modifying rules, mediating disputes over them, and enforcing them. The necessity of this framework is logically derived from the impossibility of absolute freedom due to conflicts between individual freedoms. The analysis then decomposes the broader problem of government's appropriate activities by applying this derived framework to isolate and examine specific, difficult economic sub-problems—such as defining property rights, managing the monetary system, and resolving conflicts between freedom to combine and compete—where these foundational conflicts become acute and the need for precise rule definition is paramount.

## Abstract Action Chain

1. Establish a fundamental conceptual distinction between surface-level phenomena and the underlying governing framework.
2. Clarify the framework's purpose and core functions using a clarifying analogy or model.
3. Logically derive the necessity of the framework from a foundational conflict or limitation within the core principles.
4. Apply the derived framework to decompose and systematically examine specific, problematic sub-domains.