---
name: "Comparative Institutional Analysis"
type: "sub_skill"
description: "Use this method when you need to evaluate different institutional or systemic responses to a well-defined problem, particularly when the problem has distinct subtypes and multiple potential solutions exist. It is appropriate for assessing trade-offs between alternatives in complex social, economic, or organizational contexts."
section_id: "f2fc4ba9-983c-41ef-8eab-c39743de0526"
main_skill_id: "main_skill_002"
normalized_pattern: "Comparative Analysis"
source_chunk_ids: [9]
---

# Comparative Institutional Analysis

## Description

Use this method when you need to evaluate different institutional or systemic responses to a well-defined problem, particularly when the problem has distinct subtypes and multiple potential solutions exist. It is appropriate for assessing trade-offs between alternatives in complex social, economic, or organizational contexts.

## Method Program Summary

Begin by defining the central problem concept and breaking it down into its constituent parts, focusing on a key subtype driven by specific causal factors. Next, systematically list the main institutional or governance alternatives proposed to manage this subtype. The core of the method involves a structured comparison of these alternatives. Evaluate them against criteria such as adaptability, tendency toward entrenchment, and responsiveness to change, using historical examples and hypothetical scenarios to illustrate relative merits and drawbacks. From this analysis, extract a general principle for choosing between the alternatives. Finally, validate the explanatory power and limits of this principle by applying it to a tangentially related problem, which tests the framework's boundary conditions and generalizability.

## Method Program Example

The method begins with conceptual clarification, defining 'monopoly' and distinguishing 'technical monopoly' as a key subtype arising from market forces. It then structures the analysis around the three possible institutional responses to this problem: private monopoly, public monopoly, and public regulation. The core of the method is a comparative evaluation of these 'evils,' using historical case studies (U.S. railroads, German railroads, the post office) and counterfactual reasoning to assess their relative disadvantages, particularly their responsiveness to change and tendency to entrench. The derived principle—that the least bad choice depends on factual circumstances and that competitive entry is a crucial test—is then applied to a new domain ('neighborhood effects' like pollution and highways) to demonstrate the framework's explanatory power and limits.

## Abstract Action Chain

1. Clarify and decompose the core problem concept, identifying key subtypes and their causes.
2. Enumerate the primary institutional or systemic alternatives available to address a key subtype.
3. Compare the alternatives using structured criteria, historical cases, and counterfactual reasoning.
4. Derive a general evaluative principle from the comparison.
5. Test the scope and robustness of the derived principle by applying it to a related but distinct problem domain.