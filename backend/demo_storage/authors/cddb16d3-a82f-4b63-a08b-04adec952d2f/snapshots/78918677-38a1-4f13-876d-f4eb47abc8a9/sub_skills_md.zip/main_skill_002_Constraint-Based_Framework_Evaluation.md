---
name: "Constraint-Based Framework Evaluation"
type: "sub_skill"
description: "This method is used when a principled framework appears to conflict with practical necessities, requiring a systematic way to determine which specific applications or cases remain valid under the framework's core principles."
section_id: "f2fc4ba9-983c-41ef-8eab-c39743de0526"
main_skill_id: "main_skill_002"
normalized_pattern: "Constraint Reasoning"
source_chunk_ids: [11]
---

# Constraint-Based Framework Evaluation

## Description

This method is used when a principled framework appears to conflict with practical necessities, requiring a systematic way to determine which specific applications or cases remain valid under the framework's core principles.

## Method Program Summary

Begin by recognizing a conceptual conflict where a guiding principle seems incompatible with real-world requirements. Resolve this not by discarding the principle, but by constructing a limited, justified scope for its application, often supported by authoritative references and pragmatic reasoning. From this bounded scope, distill the essential functions or core principles that are defensible. Then, treat these core principles as a set of evaluative constraints. Apply this constraint-based framework to a range of specific instances, activities, or policies. The final step is to systematically categorize and list those instances that violate the established constraints, thereby delineating the boundary of what is permissible under the adapted framework.

## Method Program Example

The analysis begins by confronting a conceptual difficulty: the conflict between liberal anti-paternalism and the perceived necessity of some paternalistic government action. It resolves this not by abandoning principle but by constraining it through pragmatic judgment and historical precedent (Dicey's quote), establishing a limited, justifiable scope. The author then defines the positive functions of government that are consistent with liberal principles. The core methodological move is to use these defined principles as a set of constraints or filters. He applies this constraint-based framework to evaluate existing government activities, systematically identifying and listing those that cannot be validated under the principles, thereby demarcating the boundary of legitimate state action.

## Abstract Action Chain

1. Identify and acknowledge a tension between a principled framework and practical demands.
2. Establish a bounded justification for the framework's application by integrating historical precedent and pragmatic necessity.
3. Define the core functions or principles that remain valid under the constrained justification.
4. Apply these defined principles as a filter or set of constraints to evaluate specific cases or activities.
5. Systematically identify and list the cases that fail to satisfy the established constraints.