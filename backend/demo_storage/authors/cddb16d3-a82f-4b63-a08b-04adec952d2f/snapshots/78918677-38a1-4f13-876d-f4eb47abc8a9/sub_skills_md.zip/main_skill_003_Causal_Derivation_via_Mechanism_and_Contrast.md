---
name: "Causal Derivation via Mechanism and Contrast"
type: "sub_skill"
description: "This method is used when you need to explain a historical or empirical pattern by deriving its underlying causal mechanism and distinguishing it from alternative explanations or interventions."
section_id: "1a45f9b7-aba8-4ce5-b690-97ac09f9922a"
main_skill_id: "main_skill_003"
normalized_pattern: "Causal Derivation"
source_chunk_ids: [1]
---

# Causal Derivation via Mechanism and Contrast

## Description

This method is used when you need to explain a historical or empirical pattern by deriving its underlying causal mechanism and distinguishing it from alternative explanations or interventions.

## Method Program Summary

First, identify and present a consistent historical or empirical pattern that requires explanation. Next, logically derive the fundamental causal mechanism—typically an incentive structure or systemic process—that generates this pattern, explaining how the mechanism operates to produce the observed outcome. Finally, contrast this derived mechanism with a plausible alternative, such as a different causal theory or a competing policy intervention, to highlight the unique explanatory power, logical coherence, or practical consequences of the primary mechanism.

## Method Program Example

The method begins by establishing a historical pattern: capitalism correlates with reduced discrimination. It then derives the causal mechanism behind this pattern: a free market separates economic efficiency from personal characteristics, creating a financial disincentive for discrimination, as it raises costs for the discriminator. Finally, the analysis contrasts this market-based, incentive-driven causal process with the alternative of legislative coercion, framing the latter as an interference with the voluntary contracts that enable the causal mechanism to function.

## Abstract Action Chain

1. Establish an observed historical or empirical pattern or correlation.
2. Derive and articulate the core causal mechanism that logically produces the observed pattern.
3. Contrast the derived causal mechanism with an alternative explanation or solution to clarify its distinct logic and implications.