---
name: "Comparative Institutional Analysis"
type: "sub_skill"
description: "This method is used when evaluating competing institutional arrangements, principles, or policies, particularly when there is a need to move beyond ideal justifications and assess them based on logical consistency, practical outcomes, or systemic performance."
section_id: "1a45f9b7-aba8-4ce5-b690-97ac09f9922a"
main_skill_id: "main_skill_003"
normalized_pattern: "Comparative Analysis"
source_chunk_ids: [3, 4]
---

# Comparative Institutional Analysis

## Description

This method is used when evaluating competing institutional arrangements, principles, or policies, particularly when there is a need to move beyond ideal justifications and assess them based on logical consistency, practical outcomes, or systemic performance.

## Method Program Summary

Begin by defining a core principle, ideal justification, or historical consensus that serves as the analytical benchmark. Systematically apply this benchmark across multiple analogous cases or contrast it with an alternative framework (e.g., market processes versus government intervention) to reveal logical inconsistencies or divergent outcomes. Shift the analysis from theoretical ideals to empirical evidence by examining specific historical or practical instances where results deviated from the initial standard. Subject these deviations or competing outcomes to a validity test based on a fundamental criterion, such as addressing coercion or evaluating systemic reliability. Finally, synthesize the comparative findings into a generalized conclusion about the structural efficacy, consistency, or inherent tendencies of the systems or principles under review.

## Method Program Example

The method begins by establishing a fundamental liberal principle: that individuals should be free to make voluntary agreements without state coercion, except to prevent coercion by others. This principle is first applied to the domain of speech (free speech) and then extended by strict analogy to the domains of employment (fair employment laws) and union membership (right-to-work laws). The analysis reveals a contradiction in those who accept the principle in one domain but reject it in another. The author then acknowledges practical complexities (e.g., monopoly power, federal law conflicts) that create deviations from the pure principle. However, the final step subjects these practical considerations to a test: they are only valid justifications for state intervention if they address coercion or monopoly, not merely to enforce a majority's preferences. The method thus uses principled consistency as the primary analytical lens, with practical factors treated as secondary tests.

## Abstract Action Chain

1. Establish a foundational principle, ideal, or historical baseline for comparison.
2. Apply the analytical lens to analogous domains or contrasting cases to test for consistency or divergence.
3. Examine empirical outcomes or practical deviations from the established standard.
4. Evaluate the validity of deviations against a core criterion (e.g., preventing coercion, systemic reliability).
5. Synthesize a general conclusion about the relative merits or systemic tendencies of the compared subjects.