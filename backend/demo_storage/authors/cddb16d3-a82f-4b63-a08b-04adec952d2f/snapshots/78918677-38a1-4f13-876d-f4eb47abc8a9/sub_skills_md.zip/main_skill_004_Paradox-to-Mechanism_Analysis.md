---
name: "Paradox-to-Mechanism Analysis"
type: "sub_skill"
description: "This method is used when confronting a puzzling or counterintuitive outcome in a social, political, or institutional system, where the observed dynamics contradict expected or normative principles. It is triggered by the need to explain why a system produces a specific paradoxical result and to uncover the underlying structural or causal forces that sustain it."
section_id: "e98009a9-2e3f-4b8e-ab74-c15bed110753"
main_skill_id: "main_skill_004"
normalized_pattern: "Mechanism Analysis"
source_chunk_ids: [6]
---

# Paradox-to-Mechanism Analysis

## Description

This method is used when confronting a puzzling or counterintuitive outcome in a social, political, or institutional system, where the observed dynamics contradict expected or normative principles. It is triggered by the need to explain why a system produces a specific paradoxical result and to uncover the underlying structural or causal forces that sustain it.

## Method Program Summary

Begin by clearly stating the paradoxical outcome that requires explanation. Proceed to select and apply a coherent explanatory mechanism—often drawn from social theory, psychology, or institutional analysis—that logically connects underlying incentives, biases, or structures to the observed paradox. Using this mechanism as a lens, break down the larger systemic issue into its constituent, mutually reinforcing elements. Then, map the causal pathways through which these elements interact, demonstrating how they collectively produce or exacerbate a systemic risk or danger. Finally, to clarify the solution space, contrast the operative mechanism with a viable alternative mechanism, thereby identifying the necessary conditions for altering the system's trajectory or resolving the paradox.

## Method Program Example

The analysis begins by posing a puzzle: why does the burden of proof rest on opponents of government growth despite its poor record? It then deploys a cited psychological and social mechanism (Dicey's argument) to explain this bias, highlighting the asymmetry between visible, immediate benefits and hidden, gradual costs of state intervention. The method then structurally decomposes the contemporary threat to freedom into two components—an external military threat and an internal ideological threat—and analyzes how they interact causally to concentrate power and endanger free institutions. Finally, it contrasts the mechanisms of social change (free institutions and persuasion versus state coercion) to derive the necessary condition for preserving the system.

## Abstract Action Chain

1. Identify and articulate the core paradoxical or puzzling outcome within the system.
2. Introduce and apply an explanatory mechanism (e.g., psychological, institutional, economic) that accounts for the genesis and persistence of the paradox.
3. Decompose the broader problem into distinct, interconnected components or reinforcing threats that stem from the core mechanism.
4. Trace the causal interactions between these components to reveal their systemic impact or danger.
5. Contrast the identified mechanism with alternative mechanisms to clarify the conditions for resolution or systemic change.