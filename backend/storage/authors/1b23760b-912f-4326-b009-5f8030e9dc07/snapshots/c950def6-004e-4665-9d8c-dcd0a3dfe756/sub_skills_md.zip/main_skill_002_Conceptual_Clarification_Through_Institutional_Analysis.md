---
name: "Conceptual Clarification Through Institutional Analysis"
type: "sub_skill"
description: "Use this method when you need to critique a flawed proposal and construct a viable alternative by resolving a core conceptual confusion, typically involving the misidentification of the type or scope of power required for a given function. It is appropriate when opposing views contain partial truths but are built on a categorical error that leads to institutional overreach or inadequacy."
section_id: "e1adabb9-cc78-448b-a2d6-706f559972d3"
main_skill_id: "main_skill_002"
normalized_pattern: "Concept Clarification"
source_chunk_ids: [8]
---

# Conceptual Clarification Through Institutional Analysis

## Description

Use this method when you need to critique a flawed proposal and construct a viable alternative by resolving a core conceptual confusion, typically involving the misidentification of the type or scope of power required for a given function. It is appropriate when opposing views contain partial truths but are built on a categorical error that leads to institutional overreach or inadequacy.

## Method Program Summary

Begin by analyzing the prevailing proposal to identify its fundamental flaw, such as an internal contradiction or a disregard for stated aims. Acknowledge any valid insight within the opposing position to establish common ground. Perform the central analytical move: clarify the conceptual confusion—often between the kind of power needed (e.g., restraining harm) and the scope proposed (e.g., directing action). From this clarified principle, logically deduce the necessary functions of a legitimate solution. Then, select an institutional form that matches these functions, such as a federation, and rigorously define it by contrasting it with both overly centralized and completely decentralized models. Finally, evaluate the proposed form by reasoning through its logical consequences, demonstrating how it resolves the initial problem while enabling desirable outcomes and blocking harmful ones.

## Method Program Example

The method begins by analyzing a prevailing intellectual trend (advocacy for a centrally directed economic order) and identifying its internal contradiction with stated war aims and its disregard for small nations. It then grants a partial truth within the opposing view (unfettered economic sovereignty is problematic) but uses this to pivot. The core analytical move is to clarify the conceptual confusion between the *kind* of power needed (negative, rule-enforcing) and the *scope* of power proposed (positive, directive). This clarification logically derives the essential functions of a legitimate international authority. The author then matches these necessary functions to an existing institutional form—federation—and rigorously defines its principle by contrasting it with both a centralized superstate and absolute national sovereignty. Finally, the method evaluates the proposed form by deducing its systemic consequences, showing how it blocks harmful planning while enabling desirable forms, thereby resolving the initial problem.

## Abstract Action Chain

1. Identify and critique a flawed proposal by exposing its internal contradictions or disregard for key principles.
2. Extract and grant the partial truth within the opposing view to establish a pivot point for analysis.
3. Clarify the core conceptual confusion, typically distinguishing between types (e.g., negative vs. positive) or scopes of power.
4. Logically derive the essential functions required for a legitimate alternative from the clarified concept.
5. Match the derived functions to a coherent institutional form and define it by contrast with extreme models.
6. Evaluate the proposed alternative by deducing its systemic consequences and advantages.