---
name: "Scaled Comparative Analysis"
type: "sub_skill"
description: "This method is used when evaluating a system, principle, or solution to determine its inherent properties, limitations, or feasibility across different contexts. It is triggered by the need to move beyond a localized or ideal-case assessment and understand how core dynamics change with scale, diversity, or complexity."
section_id: "e1adabb9-cc78-448b-a2d6-706f559972d3"
main_skill_id: "main_skill_002"
normalized_pattern: "Comparative Analysis"
source_chunk_ids: [5, 9]
---

# Scaled Comparative Analysis

## Description

This method is used when evaluating a system, principle, or solution to determine its inherent properties, limitations, or feasibility across different contexts. It is triggered by the need to move beyond a localized or ideal-case assessment and understand how core dynamics change with scale, diversity, or complexity.

## Method Program Summary

Begin by defining the core subject and its operational conditions within a constrained, favorable context. Then, construct a comparative framework by progressively applying the subject to contexts of increasing scale, heterogeneity, or complexity. At each stage, analyze how the foundational variables that supported the subject in the baseline context (e.g., shared values, agreement, homogeneity) diminish. Logically deduce the new systemic requirements or inevitable outcomes (e.g., coercion, conflict, inefficacy) that must arise to compensate for this diminishment. Finally, synthesize these findings to articulate a general principle about the subject's inherent limitations or to propose a more viable, principle-based alternative designed for the scaled reality.

## Method Program Example

The method begins by establishing a baseline understanding of economic planning within a homogeneous, small-scale context where it is relatively feasible due to shared values and goals. It then systematically scales the analysis to larger and more heterogeneous contexts—first national, then international. At each step, the analysis focuses on how the decrease in shared standards and the increase in value divergence fundamentally alter the requirements for implementing the plan, transforming it from a cooperative endeavor into one necessitating coercion. This comparative scaling is reinforced with illustrative thought experiments (e.g., Norwegian fisherman vs. Portuguese, international authority dictating to Britain) to concretize the abstract logical progression. The final step is to generalize from this scaled comparison, concluding that the coercive and immoral outcomes are not contingent on the planners' character but are inherent to the task of large-scale planning across diversity.

## Abstract Action Chain

1. Establish a baseline understanding of the subject in a simple or homogeneous context where it appears viable.
2. Systematically scale the analysis to larger, more diverse, or more complex contexts, tracking how key enabling variables inversely change.
3. Derive the necessary structural consequences or failure modes that emerge from this change in variables.
4. Contrast the outcomes with the baseline or with a scaled alternative to generalize about the subject's inherent nature or requirements.