---
name: "Structural Causal Derivation"
type: "sub_skill"
description: "Use this method when you need to demonstrate why a specific outcome is inevitable, given a set of foundational premises and logical constraints. It is appropriate for analyzing systemic problems, institutional failures, or policy consequences where surface-level explanations are insufficient and the underlying causal structure must be revealed."
section_id: "264b7ac1-080d-4af4-a2c9-c7b87dcd5d7e"
main_skill_id: "main_skill_003"
normalized_pattern: "Causal Derivation"
source_chunk_ids: [2, 3, 5]
---

# Structural Causal Derivation

## Description

Use this method when you need to demonstrate why a specific outcome is inevitable, given a set of foundational premises and logical constraints. It is appropriate for analyzing systemic problems, institutional failures, or policy consequences where surface-level explanations are insufficient and the underlying causal structure must be revealed.

## Method Program Summary

Begin by positing a fundamental, often epistemological or structural, premise that serves as the logical starting point. Alternatively, identify a widely acknowledged problem or contradiction within a system. From this foundation, deductively derive the core normative principles or isolate the essential, inherent cause of the problem, often by contrasting the case with other domains where similar structures function. Using this derived framework, logically trace the chain of necessary consequences that unfold when actions or institutional designs violate these principles or attempt to resolve the inherent contradiction. Finally, demonstrate how this causal chain leads inevitably to a specific, systemic outcome—such as institutional paralysis, coercion, or the erosion of foundational values—thereby revealing the deep structure of the problem.

## Method Program Example

The method begins by positing a fundamental epistemological fact: the limits of individual imagination and the consequent existence of only partial, subjective scales of value. From this descriptive premise, the author derives the core normative principle of individualism—that the individual should be the ultimate judge within a defined sphere. This principle then logically defines the permissible scope of collective action (like the state) as being limited to areas of coincident individual ends. The analysis then extends this logic dynamically: if collective control expands beyond this limited sphere where agreement exists, it indirectly dominates the entire system, subordinating all individual ends. Finally, the method applies this derived framework to a specific case (democratic planning), showing how the attempt to plan without underlying agreement on ends leads to a cascade of logical consequences: the impossibility of creating a specific plan, the paralysis of democratic institutions, and the inevitable shift toward expert authoritarianism.

## Abstract Action Chain

1. Establish a foundational premise or identify a recognized systemic contradiction.
2. Derive core principles or isolate the essential cause through logical contrast and deduction.
3. Trace the necessary causal chain from the derived principles to their systemic consequences.
4. Demonstrate the inevitable outcome or institutional failure that results from violating the logical constraints.