---
name: "Systemic Tension-Driven Causal Analysis"
type: "sub_skill"
description: "This method is used when analyzing a complex system or process to explain how an inherent, fundamental contradiction generates a predictable sequence of institutional failures and a specific systemic outcome. It is appropriate when the observed outcome appears inevitable rather than contingent, and when institutional mechanisms designed to prevent it have demonstrably broken down."
section_id: "264b7ac1-080d-4af4-a2c9-c7b87dcd5d7e"
main_skill_id: "main_skill_003"
normalized_pattern: "Causal Chain Analysis"
source_chunk_ids: [4]
---

# Systemic Tension-Driven Causal Analysis

## Description

This method is used when analyzing a complex system or process to explain how an inherent, fundamental contradiction generates a predictable sequence of institutional failures and a specific systemic outcome. It is appropriate when the observed outcome appears inevitable rather than contingent, and when institutional mechanisms designed to prevent it have demonstrably broken down.

## Method Program Summary

Begin by isolating a fundamental and unresolvable tension at the heart of the system under study. Construct a logical chain demonstrating how this tension, once operative, forces a sequence of institutional adaptations or failures. Use specific historical or empirical instances not merely as examples, but as confirmatory evidence that this logical sequence manifests in reality. To strengthen the causal argument, examine a proposed institutional solution or safeguard and demonstrate how the core tension systematically erodes the conditions necessary for that solution to function. Finally, synthesize the chain of causes to conclude with the systemic endpoint or transformation that the initial tension makes inevitable.

## Method Program Example

The method begins by establishing a fundamental tension within a system—here, between comprehensive economic planning and democratic decision-making. It then traces the causal chain this tension sets in motion: delegation of planning tasks leads to fragmentation and impasse within democratic bodies, which in turn generates a demand for dictatorial power to overcome the impasse. Historical examples (pre-Hitler Germany, interwar Britain) are presented not merely as illustrations but as evidence of the logical progression playing out in reality. The analysis then tests and refutes a potential counter-argument (that parliamentary sovereignty can retain control) by demonstrating how the planning process inherently undermines the conditions for effective parliamentary direction. Finally, the chain is concluded by deriving the inevitable systemic outcome: the transformation of democracy into a plebiscitary dictatorship when it attempts comprehensive planning.

## Abstract Action Chain

1. Identify and define the core, inherent tension or contradiction within the system.
2. Trace the logical, causal progression of this tension through institutional actions and reactions.
3. Validate the logical progression using historical or empirical cases as evidence.
4. Test and refute potential institutional safeguards or counter-arguments by showing how the tension undermines them.
5. Derive the inevitable systemic outcome from the completed causal chain.