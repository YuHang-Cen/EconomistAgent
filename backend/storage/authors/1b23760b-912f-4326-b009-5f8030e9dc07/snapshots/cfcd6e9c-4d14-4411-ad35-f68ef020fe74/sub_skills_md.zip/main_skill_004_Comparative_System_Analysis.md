---
name: "Comparative System Analysis"
type: "sub_skill"
description: "This method is used when analyzing complex social, political, or economic systems to understand their inherent logic, consequences, and normative implications. It is triggered by the need to systematically contrast two or more competing systems (e.g., collectivism vs. individualism) to reveal their defining features, derived outcomes, and ultimate effects on power structures, morality, and individual life."
section_id: "a89729ec-c65d-45e0-af78-6291312f3fc6"
main_skill_id: "main_skill_004"
normalized_pattern: "Comparative Analysis"
source_chunk_ids: [9, 10]
---

# Comparative System Analysis

## Description

This method is used when analyzing complex social, political, or economic systems to understand their inherent logic, consequences, and normative implications. It is triggered by the need to systematically contrast two or more competing systems (e.g., collectivism vs. individualism) to reveal their defining features, derived outcomes, and ultimate effects on power structures, morality, and individual life.

## Method Program Summary

To conduct a comparative system analysis, first define the foundational premises and core features of the systems being compared. Construct a clear analytical framework based on this contrast. Next, identify the distinct sets of outcomes—such as social virtues, institutional forms, or power structures—that are cultivated or discouraged within each system. Then, perform a logical derivation, tracing how the core principles of each system necessarily lead to these specific consequences in domains like ethics, governance, and social behavior. Finally, assess the broader normative significance of these derived consequences, evaluating their impact on fundamental societal values and individual welfare.

## Method Program Example

The method begins by isolating the defining features of a collectivist system: a common set of ends for the group and the desire to maximize the group's power to achieve them. It then systematically contrasts these features and their logical implications with those of an individualist, competitive system. The analysis proceeds in two main domains: first, it demonstrates how the centralization of planning power under collectivism creates a qualitatively greater and inescapable form of power compared to the decentralized, limited economic power in a competitive system. Second, it traces how the collectivist principles necessitate a different ethical system, one where the 'end justifies the means' becomes the supreme rule, abolishing general and absolute moral prohibitions. The conclusion evaluates these derived consequences as threats to individual freedom and morality.

## Abstract Action Chain

1. Establish a comparative framework by defining the core principles and features of the systems under analysis.
2. Populate the framework by identifying and contrasting the characteristic outcomes, virtues, or institutional forms each system produces.
3. Trace the logical and causal derivation from each system's core principles to its necessary social, moral, and power-related consequences.
4. Evaluate the normative implications of the derived consequences for key values such as freedom, morality, and social order.