---
name: "Conceptual Grounding for Normative Analysis"
type: "sub_skill"
description: "This method is used when confronting a widely held but problematic claim, belief, or policy proposal that appears to lead to undesirable social or moral consequences. It is triggered by the need to move beyond surface-level debate to uncover the foundational principles at stake and derive clear normative guidance."
section_id: "373bd259-d0bb-425f-9c17-d8076bbb5683"
main_skill_id: "main_skill_003"
normalized_pattern: "Concept Clarification"
source_chunk_ids: [1, 3]
---

# Conceptual Grounding for Normative Analysis

## Description

This method is used when confronting a widely held but problematic claim, belief, or policy proposal that appears to lead to undesirable social or moral consequences. It is triggered by the need to move beyond surface-level debate to uncover the foundational principles at stake and derive clear normative guidance.

## Method Program Summary

Begin by selecting a specific, influential claim or a concrete socio-economic problem for examination. Analyze this target not in isolation, but within the structural constraints of the system it operates in (e.g., a complex civilization, post-war reconstruction). Next, perform a consequentialist analysis by logically projecting the outcomes of consistently applying the problematic claim or policy, often highlighting a path toward political or moral decay. The pivotal step is to identify and rigorously define a fundamental concept (e.g., morality, freedom, necessity) that is being misapplied or forgotten in the prevailing discourse. This conceptual clarification acts as an anchor, recontextualizing the original problem. Finally, use this clarified principle as a logical foundation to construct a coherent normative argument, prescribing the conditions or policies necessary to align outcomes with the upheld principle.

## Method Program Example

The method begins by isolating a widely held contemporary belief—the 'End of Economic Man'—for scrutiny. The author then tests this claim against observable social demands and doctrines, finding a contradiction: while proclaiming the end of economic motivation, society is in fact more governed by economic doctrines. This contradiction is resolved by redefining the core phenomenon not as a diminished desire for material welfare, but as a 'revolt' against impersonal forces and a refusal to submit to necessities that are not fully intelligible. The analysis then shifts to examining the structural preconditions of a complex civilization, arguing that such a system necessarily relies on individuals adjusting to forces they cannot fully comprehend. Finally, the method contrasts the two possible outcomes of this revolt: continued submission to the impersonal market or submission to the arbitrary power of other men, framing this as a critical choice with severe consequences.

## Abstract Action Chain

1. Isolate and diagnose the target claim or problem within its immediate context.
2. Trace the causal or logical implications of adhering to the problematic claim, revealing its potential negative consequences.
3. Clarify a core, underlying concept or principle that has been obscured or misunderstood.
4. Use the clarified concept to reframe the original problem and derive a principled solution or normative prescription.