---
name: "Functional Selection Pressure Analysis"
type: "sub_skill"
description: "This method is used when analyzing how a system's core functional requirements create selective pathways that systematically favor certain traits or behaviors over others, leading to predictable transformations in the system's composition or character over time."
section_id: "a89729ec-c65d-45e0-af78-6291312f3fc6"
main_skill_id: "main_skill_004"
normalized_pattern: "Mechanism Analysis"
source_chunk_ids: [11]
---

# Functional Selection Pressure Analysis

## Description

This method is used when analyzing how a system's core functional requirements create selective pathways that systematically favor certain traits or behaviors over others, leading to predictable transformations in the system's composition or character over time.

## Method Program Summary

Begin by defining the non-negotiable functional goals that drive the system's operations. Next, deduce the concrete actions and institutional roles essential for meeting those goals. Then, characterize the personal or moral dispositions that align with—and are demonstrated by—effective performance in those roles. Subsequently, examine how the system's internal logic for advancement or survival formally or informally rewards individuals possessing these dispositions, creating a selective filter. Finally, extrapolate the logical endpoint of this filtering process to determine how the system's population, leadership, or overall character will be transformed if the selection pressure continues unabated.

## Method Program Example

The analysis begins by identifying the core functional imperatives of a totalitarian system, such as the need for control, intimidation, and ideological conformity. It then maps these imperatives to specific institutional roles and actions, noting their inherent moral character (e.g., cruelty, deception). The method proceeds to analyze the type of individual—defined by moral disposition—who would be both willing and able to perform these actions. It then traces the mechanism by which this willingness becomes a criterion for promotion within the system, creating a selective pathway to power. Finally, it synthesizes these steps to predict the inevitable systemic outcome: the ascent of the ruthless and unscrupulous to leadership positions, transforming the moral character of the ruling class.

## Abstract Action Chain

1. Identify the system's core functional imperatives and operational requirements.
2. Map these requirements to the specific actions, roles, or behaviors they necessitate within the system.
3. Analyze the inherent traits or dispositions required to perform or excel in those actions/roles.
4. Trace the mechanism by which these traits become criteria for reward, promotion, or success within the system.
5. Predict the long-term systemic outcome resulting from the sustained operation of this selection mechanism.