---
name: "Systemic Selection Mechanism Analysis"
type: "sub_skill"
description: "Use this method when you need to explain why a particular social, political, or organizational system consistently produces certain types of outcomes or elevates specific character types, moving beyond attributing results to chance or individual actors to reveal inherent structural logic."
section_id: "373bd259-d0bb-425f-9c17-d8076bbb5683"
main_skill_id: "main_skill_003"
normalized_pattern: "Mechanism Analysis"
source_chunk_ids: [6]
---

# Systemic Selection Mechanism Analysis

## Description

Use this method when you need to explain why a particular social, political, or organizational system consistently produces certain types of outcomes or elevates specific character types, moving beyond attributing results to chance or individual actors to reveal inherent structural logic.

## Method Program Summary

Begin by isolating a common assumption that explains a recurring systemic outcome as accidental or exceptional. Propose an alternative explanation centered on the system's internal logic. Define the system's fundamental operational requirements and the pressures these requirements generate. Determine which human traits, skills, or moral dispositions are functionally advantageous or necessary for success and survival within those pressures. Synthesize this analysis to demonstrate how the system's structure selectively promotes certain types of individuals or behaviors, making the observed outcome a predictable, non-accidental result of the system's design.

## Method Program Example

The author begins by identifying and challenging a comforting belief—that the worst features of totalitarianism are historical accidents, not systemic necessities. He then establishes the core analytical mechanism: a collectivist or totalitarian system creates specific institutional requirements and selection pressures. The analysis proceeds by examining the qualities (ruthlessness, uninhibited action) that lead to success within such a system and the moral attitudes the system's machinery demands to function. From this interaction between institutional structure and individual character, the author derives the inevitable consequence: the system will favor and elevate the 'unscrupulous and uninhibited,' making it certain that 'the worst get on top.'

## Abstract Action Chain

1. Identify and challenge a prevailing belief that attributes systemic outcomes to contingent factors.
2. Establish the core causal mechanism by defining the system's operational requirements and inherent logic.
3. Analyze the selection pressures the system creates, mapping which traits or behaviors it rewards and punishes.
4. Examine the interaction between the system's functional demands and the qualities of potential actors within it.
5. Derive the inevitable or highly probable consequence from this structural analysis, showing the outcome as a necessary product of the system.