---
name: "Constraint-Based Consequence Analysis"
type: "sub_skill"
description: "This method is used when evaluating policy proposals, social arrangements, or normative arguments that appear to solve one problem but risk violating fundamental principles or creating systemic contradictions. It is triggered by the need to assess the long-term viability and logical coherence of an approach against core constraints."
section_id: "373bd259-d0bb-425f-9c17-d8076bbb5683"
main_skill_id: "main_skill_003"
normalized_pattern: "Constraint Reasoning"
source_chunk_ids: [2]
---

# Constraint-Based Consequence Analysis

## Description

This method is used when evaluating policy proposals, social arrangements, or normative arguments that appear to solve one problem but risk violating fundamental principles or creating systemic contradictions. It is triggered by the need to assess the long-term viability and logical coherence of an approach against core constraints.

## Method Program Summary

Begin by analyzing a popular but problematic argument or proposal. Clearly articulate the fundamental, non-negotiable principles or constraints that govern the domain, noting any legitimate but bounded exceptions. Systematically apply these constraints to a concrete, forward-looking case to test the proposal's coherence. Trace the chain of effects that would follow from attempting to bypass the constraints, showing how they lead to internal contradictions, resource misallocation, or outcomes that undermine the original goal. The procedure reveals why the flawed approach is unsustainable and helps identify the boundaries within which viable solutions must operate.

## Method Program Example

The method begins by critiquing a popular but dangerous analogy (mastering society like nature). It then establishes a fundamental constraint: individual freedom is incompatible with the permanent subordination of society to a single overriding purpose, with war as the sole temporary exception. This principle is then rigorously applied to the post-war employment challenge. The analysis deduces that the constraint of freedom (no coercion) and the constraint against unemployment 'at any price' are incompatible with the economic necessity of wage adjustments. It demonstrates that attempts to circumvent these constraints through monetary policy lead to inflation, resource misallocation, and ultimately a self-defeating cycle that lowers productivity and increases the very problem it seeks to solve.

## Abstract Action Chain

1. Identify and critique a proposed solution or analogy that appears plausible but is fundamentally flawed.
2. Establish the core normative or practical constraints that any viable system must respect.
3. Apply the established constraints rigorously to a specific, anticipated future scenario.
4. Deduce the logical consequences, trade-offs, and potential self-defeating outcomes of violating the constraints.
5. Conclude by demonstrating the systemic failure or greater harm produced by the flawed approach.