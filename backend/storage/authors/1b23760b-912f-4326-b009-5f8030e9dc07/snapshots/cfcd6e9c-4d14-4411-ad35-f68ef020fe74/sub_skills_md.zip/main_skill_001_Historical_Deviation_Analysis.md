---
name: "Historical Deviation Analysis"
type: "sub_skill"
description: "Use this method when diagnosing a contemporary societal crisis or undesirable outcome, and when conventional explanations (e.g., blaming external forces or accidents) appear insufficient. It is appropriate when you suspect the root cause is an internal, long-term intellectual shift that has deviated from a foundational tradition."
section_id: "ca255b4c-8b32-4901-8b8e-453c2f7f1776"
main_skill_id: "main_skill_001"
normalized_pattern: "Historical Deviation Analysis"
source_chunk_ids: [1]
---

# Historical Deviation Analysis

## Description

Use this method when diagnosing a contemporary societal crisis or undesirable outcome, and when conventional explanations (e.g., blaming external forces or accidents) appear insufficient. It is appropriate when you suspect the root cause is an internal, long-term intellectual shift that has deviated from a foundational tradition.

## Method Program Summary

Begin by clearly defining the contemporary crisis or problematic outcome. Systematically examine and reject superficial or commonly accepted explanations for it. Shift the analysis to the historical development of dominant social ideas, reconstructing their intellectual lineage over a significant period. Contrast this actual historical trajectory with the society's cherished self-perception or stated ideals. Within this history, pinpoint a decisive intellectual turn or adoption of a new set of ideas. Frame this turn not as progress, but as a fundamental deviation from a core intellectual or philosophical tradition considered foundational to that society. Finally, construct a causal argument demonstrating how the pursuit of these deviant ideas logically produced the initially diagnosed crisis as an unintended consequence.

## Method Program Example

The method begins by diagnosing a contemporary civilizational crisis (totalitarianism, loss of freedom). It then systematically challenges the common explanations for this crisis, which blame external 'sinister forces.' Instead, the analysis pivots to a historical examination of ideas, arguing that the true cause is an internal intellectual error. It traces a gradual but decisive shift in dominant social ideals over the preceding generation—a move toward socialism and away from economic liberalism—and frames this not as progress but as a profound deviation from the core intellectual tradition of Western civilization (stemming from classical, Christian, and liberal sources). The final step is to causally connect this ideological deviation to the observed political and social outcomes, presenting the crisis as the unintended but logical result of pursuing flawed ideals.

## Abstract Action Chain

1. Diagnose the present crisis and challenge its conventional explanations
2. Trace the historical lineage of the dominant ideas, contrasting them with the society's self-perception
3. Identify a decisive intellectual shift as a deviation from a foundational tradition
4. Establish a causal link between this ideological deviation and the observed crisis