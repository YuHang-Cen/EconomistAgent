---
name: "Structural Dilemma Analysis"
type: "sub_skill"
description: "Use this method when you need to analyze a complex systemic problem by revealing its underlying structural trade-offs and deriving their long-term consequences. It is appropriate when facing a situation with multiple apparent solutions, each producing undesirable outcomes, indicating a deeper, persistent dilemma."
section_id: "dfd3f457-6469-4d71-a875-ff1213ea364e"
main_skill_id: "main_skill_002"
normalized_pattern: "Causal Derivation"
source_chunk_ids: [6]
---

# Structural Dilemma Analysis

## Description

Use this method when you need to analyze a complex systemic problem by revealing its underlying structural trade-offs and deriving their long-term consequences. It is appropriate when facing a situation with multiple apparent solutions, each producing undesirable outcomes, indicating a deeper, persistent dilemma.

## Method Program Summary

Begin by defining a specific, acute instance of a systemic problem to ground the analysis. Logically map out the complete set of available responses or choices for addressing the problem. Systematically trace the causal chain of negative outcomes that each response inevitably produces, demonstrating that all apparent solutions are flawed. Abstract this no-win scenario to identify the underlying, persistent structural principle or trade-off it exemplifies. Finally, project the long-term systemic effects—such as reduced efficiency or new forms of instability—that arise from attempts to circumvent or mitigate the core dilemma rather than resolve it.

## Method Program Example

The method begins by establishing a concrete post-war scenario: the mismatch between wartime employment/wages and peacetime economic needs. It then logically deduces the limited set of policy responses available (coercion, unemployment, or inflation) and analyzes the negative causal consequences of each, particularly focusing on inflationary measures. This specific analysis is then elevated to a general principle about the constant need for economic adaptation to change. Finally, the method derives the long-term, self-defeating systemic outcomes (lower productivity, increased artificial employment) of persistently avoiding the core dilemma through monetary policy.

## Abstract Action Chain

1. Establish a concrete problem scenario that highlights a core structural tension.
2. Deduce the limited set of logical alternatives or policy responses available.
3. Evaluate the negative causal consequences inherent to each alternative.
4. Generalize the specific case into a universal structural principle or dilemma.
5. Derive the long-term systemic implications of avoiding or managing this core dilemma.