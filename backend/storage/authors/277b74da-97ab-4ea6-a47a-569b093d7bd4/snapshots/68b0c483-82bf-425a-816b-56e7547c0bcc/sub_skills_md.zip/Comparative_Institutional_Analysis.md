---
name: "Comparative Institutional Analysis"
type: "sub_skill"
description: "This method is used when evaluating competing institutional proposals, policy frameworks, or governance models to determine their feasibility, internal consistency, and likely consequences. It is triggered by the need to assess abstract ideals against practical realities, expose hidden contradictions in advocated positions, or derive design principles from empirical patterns."
section_id: "a3a1efa9-0250-43f9-9caf-36106bc362dd"
main_skill_id: "main_skill_001"
normalized_pattern: "Comparative Analysis"
source_chunk_ids: [2, 6, 8]
---

# Comparative Institutional Analysis

## Description

This method is used when evaluating competing institutional proposals, policy frameworks, or governance models to determine their feasibility, internal consistency, and likely consequences. It is triggered by the need to assess abstract ideals against practical realities, expose hidden contradictions in advocated positions, or derive design principles from empirical patterns.

## Method Program Summary

Begin by clearly identifying the institutional proposal, ideal, or policy framework under examination, noting its advocates and stated objectives. Systematically analyze this target by exposing its internal logical contradictions or by contrasting its assumptions with observed empirical patterns and historical outcomes. From this comparative analysis, derive a general principle—such as a limitation of scale, a conflict between means and ends, or a condition for effective governance. Apply this principle to construct a superior institutional alternative that addresses the identified flaws, typically favoring limited, rules-based orders over centralized, planning-based systems. Finally, validate the proposed alternative by demonstrating its logical coherence, its safeguards against concentrated power, and its alignment with empirical evidence of successful governance models.

## Method Program Example

The analysis begins by establishing a premise: economic planning faces fewer difficulties in small, homogeneous groups like families or small communities due to shared values and goals. It then scales this scenario up to the national level, noting that agreement on ends decreases and the need for compulsion grows. The core methodological move is to extrapolate this scaling effect further to the international level. The argument demonstrates that the fundamental conflict between planning and freedom becomes exponentially more severe as the scale increases, because the necessary preconditions—common standards, values, and a sense of shared identity—disintegrate. This logical progression is then solidified with vivid, concrete examples of potential international conflicts to make the abstract scaling argument tangible and persuasive.

## Abstract Action Chain

1. Identify and characterize the target proposal or ideal being analyzed
2. Expose internal contradictions or contrast the proposal with observed empirical realities
3. Derive a general principle or limitation from the comparative analysis
4. Apply the derived principle to propose a superior institutional alternative
5. Support the alternative with logical safeguards and empirical validation