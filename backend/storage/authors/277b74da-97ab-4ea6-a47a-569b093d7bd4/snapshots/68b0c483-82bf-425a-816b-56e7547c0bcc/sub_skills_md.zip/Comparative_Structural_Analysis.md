---
name: "Comparative Structural Analysis"
type: "sub_skill"
description: "Use when you need to reveal the underlying logic or necessity of a system by contrasting it with an analogous domain that shares surface similarities but differs in a fundamental structural feature."
section_id: "deea4935-7f14-4bf5-a517-aad7f692fd51"
main_skill_id: "main_skill_002"
normalized_pattern: "Comparative Analysis"
source_chunk_ids: [14]
---

# Comparative Structural Analysis

## Description

Use when you need to reveal the underlying logic or necessity of a system by contrasting it with an analogous domain that shares surface similarities but differs in a fundamental structural feature.

## Method Program Summary

Begin by selecting two domains that are functionally or conceptually analogous, allowing for a meaningful comparison. Analyze and clearly define the core structural difference between them, focusing on features like goal unity versus goal plurality, or centralized versus distributed knowledge. From this identified difference, logically deduce the necessary requirements for decision-making, authority, and expertise within the system under study. Finally, extrapolate the broader, often progressive, consequences this logical necessity imposes on related institutions, governance structures, or social practices, revealing the systemic implications of the initial structural condition.

## Method Program Example

The method begins by establishing a comparison between military command and economic planning, highlighting that the former has a single, defined supreme goal, while the latter inherently involves balancing multiple conflicting ends. From this contrast, the author deduces that economic planning requires knowledge of all facts and value judgments, which logically leads to decision-making by experts imposing their preferences. This deduction is then used to analyze the real reason for delegation of power (not technical detail, but the need for discretionary decisions), and finally, the analysis traces the progressive, systemic consequences of this need for comprehensive planning on democratic institutions, showing how it leads to the relinquishment of legislative power and demands for centralized authority.

## Abstract Action Chain

1. Select two analogous domains for structural comparison
2. Identify and articulate the core structural difference between them
3. Deduce the logical implications of this difference for decision-making and authority
4. Trace the systemic or institutional consequences that follow from this logical necessity