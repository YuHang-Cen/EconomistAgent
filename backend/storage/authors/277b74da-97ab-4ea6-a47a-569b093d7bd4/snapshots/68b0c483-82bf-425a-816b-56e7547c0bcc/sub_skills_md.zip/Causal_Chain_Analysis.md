---
name: "Causal Chain Analysis"
type: "sub_skill"
description: "This method is used when a complex systemic problem requires tracing the logical sequence from a foundational principle or condition through intermediate causal mechanisms to final institutional or social outcomes. It is appropriate for analyzing how exceeding a critical threshold in one domain triggers a chain of consequences that reshape the entire system."
section_id: "deea4935-7f14-4bf5-a517-aad7f692fd51"
main_skill_id: "main_skill_002"
normalized_pattern: "Causal Chain Analysis"
source_chunk_ids: [12]
---

# Causal Chain Analysis

## Description

This method is used when a complex systemic problem requires tracing the logical sequence from a foundational principle or condition through intermediate causal mechanisms to final institutional or social outcomes. It is appropriate for analyzing how exceeding a critical threshold in one domain triggers a chain of consequences that reshape the entire system.

## Method Program Summary

Begin by positing a core principle that defines the system's operational logic. Next, introduce a causal mechanism that links changes in one variable to broader systemic effects, specifying a critical point where the nature of the system shifts. Substantiate this chain by tracing the logical progression of consequences, demonstrating how each stage leads to the next. To make the abstract consequences tangible, illustrate the resulting contradictions or breakdowns using a relevant analogy or historical case. Finally, examine the terminal point of the chain, showing how the accumulated effects manifest as specific institutional failures or social transformations.

## Method Program Example

The method begins by positing a core principle: voluntary agreement limits state action. It then introduces a causal mechanism where expanding the communal sector beyond a certain point leads to indirect control over the entire system. This causal chain is substantiated with a quantitative example (Germany, 1928). The analysis then shifts to the political sphere, tracing the consequences of this systemic shift: planning without substantive agreement on ends creates an impossible demand for consensus, which is illustrated with the analogy of a journey without a destination. Finally, the method examines the institutional outcome, showing how this contradiction leads to the failure of democratic assemblies and the transfer of power to experts.

## Abstract Action Chain

1. Establish a foundational principle or logical premise governing the system.
2. Identify a critical threshold or tipping point within the causal mechanism.
3. Deduce the systemic consequences that unfold from exceeding that threshold.
4. Illustrate the resulting contradictions or failures through analogy or concrete example.
5. Analyze the final institutional or social outcomes of the causal chain.