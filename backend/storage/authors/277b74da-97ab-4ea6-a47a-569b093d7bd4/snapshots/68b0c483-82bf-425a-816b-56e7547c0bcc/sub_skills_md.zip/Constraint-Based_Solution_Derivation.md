---
name: "Constraint-Based Solution Derivation"
type: "sub_skill"
description: "Use this method when analyzing a proposed system, principle, or solution that faces a significant tension between its ideal objectives and inherent practical limitations. It is appropriate for deriving viable operational forms or predicting systemic outcomes from structural contradictions."
section_id: "a3a1efa9-0250-43f9-9caf-36106bc362dd"
main_skill_id: "main_skill_001"
normalized_pattern: "Constraint Reasoning"
source_chunk_ids: [3, 9]
---

# Constraint-Based Solution Derivation

## Description

Use this method when analyzing a proposed system, principle, or solution that faces a significant tension between its ideal objectives and inherent practical limitations. It is appropriate for deriving viable operational forms or predicting systemic outcomes from structural contradictions.

## Method Program Summary

Begin by clearly stating the system's core task or the principle's ideal goal. Immediately identify the fundamental structural constraints, contradictions, or practical difficulties that make the ideal form unworkable. Logically deduce the necessary operational consequences or failure modes that arise from these constraints, testing this derivation against historical examples or counterfactual scenarios. Finally, synthesize a revised proposal that hierarchically addresses the problem: prioritize a feasible, limited application that works within the primary constraints, while acknowledging broader, looser mechanisms for residual issues, thereby avoiding the failure caused by overextension.

## Method Program Example

The author begins by defining the core task of the system under analysis: the centralized direction of economic life across diverse peoples. He then identifies the system's inherent structural constraints, primarily the clash of divergent ideals, values, and economic interests. From these constraints, he logically derives the necessary operational consequence: the impossibility of democratic execution and the inevitable resort to force by a dominant group. This derivation is tested and reinforced by applying it to a concrete historical example (German Grossraumwirtschaft) and by considering a counterfactual scenario (an idealistic, unselfish planner) to demonstrate that the coercive outcome is a function of the task's structure, not the actors' morality.

## Abstract Action Chain

1. Define the core objective and identify its inherent structural constraints or contradictions.
2. Analyze the operational consequences of these constraints, often using historical or logical tests.
3. Derive and propose a modified or tiered solution that prioritizes feasibility within the constrained reality.