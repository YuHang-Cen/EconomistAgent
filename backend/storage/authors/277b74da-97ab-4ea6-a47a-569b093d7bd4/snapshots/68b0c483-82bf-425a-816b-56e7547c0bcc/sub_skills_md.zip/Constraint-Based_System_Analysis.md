---
name: "Constraint-Based System Analysis"
type: "sub_skill"
description: "This method is used when analyzing a system, institution, or normative framework that appears to be failing or is under theoretical scrutiny. It is triggered by the need to explain limitations, contradictions, or inherent boundaries of action, rather than surface-level inefficiencies."
section_id: "deea4935-7f14-4bf5-a517-aad7f692fd51"
main_skill_id: "main_skill_002"
normalized_pattern: "Constraint Reasoning"
source_chunk_ids: [11, 13]
---

# Constraint-Based System Analysis

## Description

This method is used when analyzing a system, institution, or normative framework that appears to be failing or is under theoretical scrutiny. It is triggered by the need to explain limitations, contradictions, or inherent boundaries of action, rather than surface-level inefficiencies.

## Method Program Summary

Begin by identifying an indisputable foundational fact, such as a cognitive limitation or a systemic contradiction, that serves as a fixed constraint. From this constraint, logically derive a core principle or requirement that governs legitimate action or successful functioning. Systematically apply this derived principle to the system in question, analyzing how its inherent logic or decision-making mechanisms interact with the demands of a specific task or goal. The analysis should demonstrate that the constraint imposes necessary and inescapable limits, leading to a conclusion about the system's legitimate scope or fundamental incapacity. Finally, solidify the argument by extending the logic to analogous situations or by showing how alternative structures would be forced by the same constraint.

## Method Program Example

The method proceeds by first positing an indisputable cognitive fact: no single mind can comprehend or weigh the infinite variety of human needs. This fact is treated as a foundational constraint. From this constraint, the author logically derives the core tenet of philosophical individualism: the individual must be the ultimate judge of their own ends. This derived principle then becomes the analytical tool. The author applies it to delineate the permissible sphere of social and state action, arguing that collective action is only legitimate where individual ends coincide, and that the scope of state power is inversely related to the likelihood of such agreement among individuals.

## Abstract Action Chain

1. Establish a foundational constraint or identify a core contradiction within the system.
2. Derive a governing principle or logical requirement from that constraint.
3. Apply the derived principle to analyze the system's capacity for a specific task or function.
4. Demonstrate the necessary limits or structural incompatibility that results.
5. Reinforce the conclusion through logical extension or analogical reasoning.