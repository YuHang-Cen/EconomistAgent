---
name: "Structural Counterexample Refutation"
type: "sub_skill"
description: "Use this method when you need to refute a systemic argument by demonstrating its structural failure under realistic operational conditions, particularly when the argument relies on an institutional safeguard that appears plausible in theory but collapses in practice."
section_id: "deea4935-7f14-4bf5-a517-aad7f692fd51"
main_skill_id: "main_skill_002"
normalized_pattern: "Counterexample Argument"
source_chunk_ids: [15]
---

# Structural Counterexample Refutation

## Description

Use this method when you need to refute a systemic argument by demonstrating its structural failure under realistic operational conditions, particularly when the argument relies on an institutional safeguard that appears plausible in theory but collapses in practice.

## Method Program Summary

Begin by contextualizing the phenomenon under analysis as a characteristic stage within a larger systemic movement. Substantiate this positioning by illustrating the phenomenon's typical progression pattern through comparative cases, showing its evolution from initial appeal to institutional manifestation. Next, present the core opposing argument that seeks to reconcile the phenomenon with a valued systemic principle, such as democratic control. To refute it, introduce a pivotal conceptual distinction that exposes a hidden structural weakness in the argument's logic. Then, construct a detailed, realistic operational scenario where the system must function under conflicting demands and holistic constraints. Use this scenario as a counterexample to demonstrate that the proposed safeguard becomes functionally powerless in practice. Finally, logically derive the inevitable systemic outcome that results from this structural failure, completing the refutation.

## Method Program Example

The analysis begins by positioning the demand for an 'economic dictator' as a symptomatic stage within the movement toward planning. It then substantiates this claim by tracing the phenomenon's evolution in two historical contexts (England and pre-Hitler Germany), showing how it progresses from intellectual appeal to institutional decay. The core of the method is a rebuttal: the author introduces a pivotal counter-argument used by planners (that ultimate parliamentary control preserves democracy) and then systematically dismantles it. This is done by drawing a fundamental distinction between two types of parliamentary delegation. The author constructs a detailed scenario of planning in action—where ends conflict and plans are holistic—to serve as a counterexample, demonstrating that parliamentary oversight becomes functionally powerless. The method concludes by logically deriving the inevitable systemic outcome (plebiscitarian dictatorship) from this failure of control.

## Abstract Action Chain

1. Position the target phenomenon as a symptomatic stage within a broader systemic trend
2. Establish the phenomenon's progression pattern through comparative historical or contextual illustrations
3. Introduce and articulate the key opposing argument that claims to preserve systemic integrity
4. Introduce a fundamental conceptual distinction that reveals a hidden structural flaw in the opposing argument
5. Construct a detailed operational scenario that serves as a counterexample, demonstrating the argument's functional failure
6. Derive the inevitable systemic consequence that logically follows from the demonstrated structural flaw