---
name: "Operational Consequence Derivation"
type: "sub_skill"
description: "This method is used when analyzing a proposed system, policy, or goal to reveal its inherent structural contradictions, power dynamics, or unintended systemic outcomes. It is triggered by encountering a normative proposal that requires centralized coordination or the ranking of competing claims."
section_id: "a3a1efa9-0250-43f9-9caf-36106bc362dd"
main_skill_id: "main_skill_001"
normalized_pattern: "Causal Derivation"
source_chunk_ids: [4]
---

# Operational Consequence Derivation

## Description

This method is used when analyzing a proposed system, policy, or goal to reveal its inherent structural contradictions, power dynamics, or unintended systemic outcomes. It is triggered by encountering a normative proposal that requires centralized coordination or the ranking of competing claims.

## Method Program Summary

Begin by clearly defining the target proposal or goal. Systematically unpack its implementation, identifying the essential operational decisions a central authority must make, particularly those involving prioritization or the balancing of competing interests. From each operational necessity, logically derive the immediate practical consequences, such as the creation of arbitrary hierarchies, perceptions of injustice, or the need for coercive enforcement. Finally, chain these consequences together to forecast how they would transform the broader system, often revealing a shift in the nature of social conflict or the emergence of new power dynamics.

## Method Program Example

The method begins by isolating a specific normative proposal (international planning for equalization). It then logically unpacks what the implementation of this proposal would necessarily entail: a central authority must rank the competing claims of different groups. From this operational necessity, the author derives the inevitable outcomes: the creation of arbitrary hierarchies, the perception of injustice among those deprioritized, and the consequent need for coercive power to enforce the plan. Finally, the argument extrapolates these outcomes to predict a shift in social conflict from class struggle within nations to international struggle between the working classes of different countries, driven by the centralized allocation of resources.

## Abstract Action Chain

1. Isolate and define the core normative proposal or systemic goal.
2. Decompose the proposal into its necessary operational steps and decision-making requirements.
3. Deduce the logical consequences and conflicts arising from each operational step.
4. Extrapolate these consequences to predict broader systemic shifts and secondary effects.