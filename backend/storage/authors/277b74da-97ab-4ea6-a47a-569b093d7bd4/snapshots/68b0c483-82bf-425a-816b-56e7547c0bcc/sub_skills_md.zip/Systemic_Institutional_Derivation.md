---
name: "Systemic Institutional Derivation"
type: "sub_skill"
description: "Use this method when you need to determine the necessary institutional or procedural forms that logically follow from the core functional requirements of a system, especially when comparing alternative systemic models."
section_id: "deea4935-7f14-4bf5-a517-aad7f692fd51"
main_skill_id: "main_skill_002"
normalized_pattern: "Causal Derivation"
source_chunk_ids: [16]
---

# Systemic Institutional Derivation

## Description

Use this method when you need to determine the necessary institutional or procedural forms that logically follow from the core functional requirements of a system, especially when comparing alternative systemic models.

## Method Program Summary

Begin by defining the essential functional logic of the system under analysis. From this foundational requirement, logically derive the institutional structures, decision-making procedures, or power arrangements that are indispensable for the system to operate effectively. To strengthen the derivation, contrast this causal chain with that of a relevant alternative system, showing how its different functional starting point leads to distinct institutional and normative consequences. The final synthesis should clarify how specific values (e.g., freedom, efficiency, stability) become possible or impossible as direct implications of each system's core logic and its required institutional form.

## Method Program Example

The method begins by establishing the fundamental operational logic of a centrally planned society: it requires conscious control over economic activity. The analysis then derives that this control cannot be contingent on wide agreement (the democratic method), as planning decisions are complex and specific. This leads to the causal conclusion that effective large-scale planning necessitates dictatorship, as it is the instrument capable of imposing the required detailed will. The argument is framed by contrasting this causal chain with that of a liberal competitive system, where the restricted scope of collective decision-making is shown to be the very condition that makes democracy and individual freedom possible. The analysis thus proceeds from systemic necessities to their inescapable institutional and normative consequences.

## Abstract Action Chain

1. Establish the fundamental operational logic or core functional requirement of the primary system.
2. Deduce the institutional or procedural forms that are causally necessitated by that requirement.
3. Contrast the derived chain with the functional requirements and consequent forms of an alternative system.
4. Synthesize the implications for normative values or broader societal conditions in each systemic context.