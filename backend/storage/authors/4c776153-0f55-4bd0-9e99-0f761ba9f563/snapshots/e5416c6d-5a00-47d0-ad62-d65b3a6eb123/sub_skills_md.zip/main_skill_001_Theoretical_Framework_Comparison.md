---
name: "Theoretical Framework Comparison"
type: "sub_skill"
description: "This method is used when an existing theoretical explanation is insufficient or its conclusions are questionable. It is triggered by the need to challenge a dominant theory by revealing its foundational limitations and demonstrating the explanatory superiority of an alternative analytical structure."
section_id: "50ff70fc-4eb1-46ac-836d-495eff4d92da"
main_skill_id: "main_skill_001"
normalized_pattern: "Comparative Analysis"
source_chunk_ids: [5]
---

# Theoretical Framework Comparison

## Description

This method is used when an existing theoretical explanation is insufficient or its conclusions are questionable. It is triggered by the need to challenge a dominant theory by revealing its foundational limitations and demonstrating the explanatory superiority of an alternative analytical structure.

## Method Program Summary

Begin by selecting a specific, consequential claim from the established theory. Critically examine this claim to identify and make explicit the foundational assumptions that enable its conclusion, highlighting their simplifying or restrictive nature. Then, propose a counter-framework built upon a revised or more comprehensive set of premises that address the limitations of the original. Finally, conduct a comparative analysis, deriving the logical implications and real-world predictions from each framework to clearly show how the alternative framework provides a more robust or accurate explanation of the phenomenon in question.

## Method Program Example

The method begins by isolating a specific theoretical claim (e.g., the self-adjusting nature of the economy via wage flexibility). It then dissects the claim to reveal its foundational, often unstated, assumptions (e.g., no propensity to hoard, constant velocity of money, full employment). Following this, the author introduces his own analytical method, built on a different set of premises (e.g., accounting for liquidity preference, uncertainty, and aggregate demand). Finally, he systematically compares the conclusions derived from both analytical structures, highlighting how the inclusion of omitted factors in his framework leads to fundamentally different predictions and policy implications regarding phenomena like wage changes and interest rates.

## Abstract Action Chain

1. Isolate and articulate a core proposition from the target theory.
2. Deconstruct the proposition to expose its underlying, often implicit, simplifying assumptions.
3. Construct an alternative analytical framework based on a different or expanded set of premises.
4. Systematically contrast the logical outcomes and empirical applicability of the two frameworks to demonstrate the alternative's explanatory advantages.