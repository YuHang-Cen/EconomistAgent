---
name: "Comparative Conceptual Analysis"
type: "sub_skill"
description: "This method is used when evaluating competing theoretical explanations for a complex systemic phenomenon, particularly when one view appears plausible in isolation but fails to account for aggregate interdependencies. It is triggered by the need to expose hidden assumptions and demonstrate the logical insufficiency of an opposing argument within a broader theoretical framework."
section_id: "c1a8617d-e611-4846-a3ec-13f098b042f0"
main_skill_id: "main_skill_002"
normalized_pattern: "Conceptual Comparison"
source_chunk_ids: [6]
---

# Comparative Conceptual Analysis

## Description

This method is used when evaluating competing theoretical explanations for a complex systemic phenomenon, particularly when one view appears plausible in isolation but fails to account for aggregate interdependencies. It is triggered by the need to expose hidden assumptions and demonstrate the logical insufficiency of an opposing argument within a broader theoretical framework.

## Method Program Summary

To execute this comparative analysis, first clarify the opposing theory's reasoning pattern, often by identifying an analogical extension from a micro-level case to the whole system. The central analytical move is to pinpoint the invalid transfer, which typically hinges on an unstated assumption of fixed aggregate conditions. Structure the problem by separating it into direct effects (holding key aggregates constant) and indirect effects (via repercussions on those aggregates). Evaluate the direct effect by applying your own established theoretical principles, which often yield a deductive result showing no change if aggregates are held fixed. To solidify the critique, perform a constrained thought experiment: assume the most favorable initial conditions for the opposing view and then logically trace the sequence of events through the interconnected variables of your systemic framework. This tracing demonstrates that the proposed causal link is incomplete and sustainable only if specific conditions within your framework are met, thereby revealing the argument's dependence on the very aggregate effects it overlooks.

## Method Program Example

The method begins by clarifying the opposing (classical) theory's reasoning pattern: it constructs a demand schedule for labor in a single industry and then analogically extends this to the economy as a whole. The author's core analytical move is to identify the invalid transfer, which hinges on the unstated assumption of fixed aggregate effective demand. Having established this as the point of contention, the author then applies his own method. He first structures the problem by separating the question into two parts: the direct effect (holding key aggregates constant) and the indirect effects (via repercussions on those aggregates). He answers the first part deductively by invoking his previously established theoretical result that employment is uniquely determined by effective demand, which cannot change if the key aggregates are unchanged. To further solidify the critique, he then engages in a constrained thought experiment: he assumes the most favorable scenario for the classical view (entrepreneurs initially expect higher profits) and logically traces the sequence of events through the system. This tracing demonstrates that increased employment can only be sustained if specific conditions within his framework (regarding the propensity to consume and investment) are met, thereby showing that the crude causal link (lower wages -> lower costs -> more employment) is incomplete and dependent on the very aggregate effects the classical theory overlooks.

## Abstract Action Chain

1. Reconstruct and formalize the logical structure of the opposing argument
2. Identify and isolate its critical hidden assumption regarding systemic aggregates
3. Decompose the core problem into direct (partial equilibrium) and indirect (general equilibrium) causal pathways
4. Apply one's own theoretical framework to evaluate the direct effect deductively
5. Conduct a constrained thought experiment under conditions most favorable to the opposing view
6. Trace the logical repercussions through key systemic variables to demonstrate insufficiency