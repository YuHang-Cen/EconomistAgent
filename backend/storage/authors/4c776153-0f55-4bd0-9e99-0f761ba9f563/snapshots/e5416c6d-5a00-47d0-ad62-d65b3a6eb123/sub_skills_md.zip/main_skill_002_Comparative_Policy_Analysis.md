---
name: "Comparative Policy Analysis"
type: "sub_skill"
description: "Use this method when you need to evaluate two or more alternative policy instruments or interventions that aim to achieve similar economic or social objectives, particularly when theoretical equivalence exists but practical implementation differs."
section_id: "c1a8617d-e611-4846-a3ec-13f098b042f0"
main_skill_id: "main_skill_002"
normalized_pattern: "Comparative Analysis"
source_chunk_ids: [8, 9]
---

# Comparative Policy Analysis

## Description

Use this method when you need to evaluate two or more alternative policy instruments or interventions that aim to achieve similar economic or social objectives, particularly when theoretical equivalence exists but practical implementation differs.

## Method Program Summary

Begin by clearly defining the alternative policy levers or mechanisms that could be used to influence the target outcome. First, analyze how these alternatives are theoretically equivalent or related in their core causal mechanism under simplified, ideal conditions. Next, systematically introduce the relevant real-world constraints—such as institutional structures, administrative practicality, social norms, or systemic stability requirements—that break this theoretical equivalence. Proceed to compare the policy options across multiple evaluative dimensions, including ease of implementation, distributional consequences, impact on systemic confidence, and adaptability to different contexts. Finally, synthesize this comparative analysis to arrive at a reasoned judgment about which policy is most advisable, balancing theoretical soundness against practical feasibility and secondary effects.

## Method Program Example

The analysis begins by identifying two potential policy levers for influencing effective demand and employment: flexible money-wages and flexible money supply. It first establishes their theoretical equivalence in affecting the rate of interest via the wage-unit. Then, it systematically introduces real-world institutional constraints—such as decentralized wage bargaining, social justice considerations, and administrative practicality—that break this equivalence. The method proceeds by comparing the two policies along multiple dimensions: ease of implementation, distributional fairness, and impact on confidence. This comparative constraint analysis leads to the conclusion that a flexible money policy is superior to a flexible wage policy, despite their analytical similarity.

## Abstract Action Chain

1. Identify and define the alternative policy instruments or mechanisms under consideration.
2. Establish their theoretical equivalence or relationship under idealized conditions.
3. Introduce and analyze real-world institutional, practical, and systemic constraints that differentiate them.
4. Compare the alternatives across dimensions of feasibility, stability, and secondary effects.
5. Derive a normative conclusion regarding the superior policy based on the comparative evaluation.