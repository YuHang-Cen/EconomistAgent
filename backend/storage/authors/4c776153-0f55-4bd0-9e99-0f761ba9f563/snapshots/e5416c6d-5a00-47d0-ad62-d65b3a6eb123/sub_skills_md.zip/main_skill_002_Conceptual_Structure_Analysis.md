---
name: "Conceptual Structure Analysis"
type: "sub_skill"
description: "This method is used when a theoretical concept, definition, or formal system is presented as an explanation for a phenomenon, but its explanatory power or logical coherence is in question. It is triggered by the need to critically evaluate the internal consistency of a conceptual framework or its ability to account for observed dynamics."
section_id: "c1a8617d-e611-4846-a3ec-13f098b042f0"
main_skill_id: "main_skill_002"
normalized_pattern: "Concept Decomposition"
source_chunk_ids: [10, 12]
---

# Conceptual Structure Analysis

## Description

This method is used when a theoretical concept, definition, or formal system is presented as an explanation for a phenomenon, but its explanatory power or logical coherence is in question. It is triggered by the need to critically evaluate the internal consistency of a conceptual framework or its ability to account for observed dynamics.

## Method Program Summary

To apply this method, first formally reconstruct the target theory by clarifying its key definitions, equations, and implicit assumptions. Next, analyze the logical structure and inherent behavioral properties (e.g., stability, variability) of this reconstructed system. Identify any critical gaps, such as insufficient equations for unknowns, or a structural incapacity to generate the dynamics the theory purports to explain. Expose the hidden assumptions required to close these gaps. Then, systematically trace the necessary implications and limitations these assumptions impose on the theory's explanatory power. Finally, contrast the theory's constrained conceptual framework with the volatile, omitted factors that are necessary for a complete account of the observed phenomenon.

## Method Program Example

The analysis begins by systematically reconstructing Pigou's theoretical framework: defining his key categories (wage-goods/non-wage-goods industries), formalizing his equations (x+y=φ(x), n=χ(x)), and clarifying his implicit assumptions (marginal wage-cost equals marginal prime cost). It then identifies a critical logical problem: the system has three unknowns but only two equations. The author deduces that Pigou must be implicitly assuming n=x+y to resolve this, which is shown to be equivalent to assuming no involuntary unemployment. This hidden assumption is then traced to its necessary implications: that demand for non-wage-goods must adjust automatically to preserve full employment, which in turn requires a specific behavior of the interest rate. Finally, the author evaluates the theory's resulting limitations, concluding it can only describe variations under full employment conditions, not explain actual employment levels or involuntary unemployment.

## Abstract Action Chain

1. Reconstruct the formal or definitional structure of the target concept or theory.
2. Analyze the internal logic and dynamic properties of the reconstructed system.
3. Identify a mismatch, logical gap, or hidden assumption within the structure.
4. Trace the implications of this identified flaw for the theory's explanatory scope.
5. Contrast the limited conceptual construct with the omitted or alternative causal factors required to explain the phenomenon.